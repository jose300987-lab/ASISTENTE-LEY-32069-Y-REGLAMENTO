package pe.contrataciones.asistente.ai

import pe.contrataciones.asistente.data.Repo
import pe.contrataciones.asistente.data.TextUtil

/**
 * Revisa una respuesta de la IA contra los textos cargados:
 *  1) cada cita [Ley, art. …] / [Reglamento, art. …] / [Opinión …] debe existir;
 *  2) cada plazo o porcentaje escrito en una línea con citas ("10 días", "15 %") debe aparecer
 *     en el texto de alguno de los artículos citados en esa línea (en cifras o en letras).
 */
object Verificador {

    private val CITA = Regex("\\[([^\\[\\]]{4,120})]")
    private val CANT = Regex("(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*(%|por\\s*ciento|d[ií]as?(?:\\s+h[áa]biles|\\s+calendario)?|meses?|años?|uit)", RegexOption.IGNORE_CASE)

    private val UNIDADES = mapOf(
        "uno" to 1, "un" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6, "siete" to 7,
        "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12, "trece" to 13, "catorce" to 14, "quince" to 15,
        "dieciseis" to 16, "diecisiete" to 17, "dieciocho" to 18, "diecinueve" to 19, "veinte" to 20, "veintiun" to 21,
        "veintiuno" to 21, "veintidos" to 22, "veintitres" to 23, "veinticuatro" to 24, "veinticinco" to 25, "veintiseis" to 26,
        "veintisiete" to 27, "veintiocho" to 28, "veintinueve" to 29
    )
    private val DECENAS = mapOf("treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60, "setenta" to 70, "ochenta" to 80, "noventa" to 90)
    private val CENTENAS = mapOf("cien" to 100, "ciento" to 100, "doscientos" to 200, "trescientos" to 300, "trescientos sesenta y cinco" to 365)

    /** Todos los números (en cifras o en letras) que aparecen en un texto. */
    fun numeros(texto: String): Set<Double> {
        val t = TextUtil.norm(texto)
        val out = HashSet<Double>()
        Regex("\\d+(?:[.,]\\d+)?").findAll(t).forEach { m -> m.value.replace(",", ".").toDoubleOrNull()?.let { out.add(it) } }
        val w = Regex("[a-z]+").findAll(t).map { it.value }.toList()
        var i = 0
        while (i < w.size) {
            var v = 0; var j = i; var hubo = false
            CENTENAS[w[j]]?.let { v += it; j++; hubo = true }
            val dec = if (j < w.size) DECENAS[w[j]] else null
            if (dec != null) {
                v += dec; j++; hubo = true
                if (j + 1 < w.size && w[j] == "y") { val u = UNIDADES[w[j + 1]]; if (u != null) { v += u; j += 2 } }
            } else if (j < w.size) {
                val u = UNIDADES[w[j]]
                if (u != null) { v += u; j++; hubo = true }
            }
            if (hubo) { out.add(v.toDouble()); i = j } else i++
        }
        if (t.contains("un decimo")) out.add(10.0)
        return out
    }

    private fun textoCitado(repo: Repo, cita: String): String? {
        val c = cita.trim()
        if (TextUtil.norm(c).startsWith("opini")) {
            val code = Regex("D\\d{6}-\\d{4}-OECE-DTN", RegexOption.IGNORE_CASE).find(c)?.value ?: return null
            val o = repo.opinion(code) ?: return null
            return o.asunto + " " + o.criterio
        }
        repo.fragByLabel(c)?.let { f -> return repo.itemOf(f)?.x ?: f.texto }
        val partes = c.split(",", limit = 2)
        val norma = repo.normaKey(partes[0]) ?: return null
        val resto = partes.getOrElse(1) { "" }
        val art = Regex("art(?:[íi]culo|s?\\.)\\s*(\\d{1,3})", RegexOption.IGNORE_CASE).find(resto)
        val item = if (art != null) repo.getArticle(norma, art.groupValues[1]) else repo.findDisposicion(norma, resto)
        return item?.x
    }

    fun revisar(repo: Repo, respuesta: String): List<String> {
        val avisos = LinkedHashSet<String>()
        // Los bloques de gráfico también se revisan: sus citas van sin corchetes dentro del JSON.
        val lineas = respuesta.lines()
        for (linea in lineas) {
            val citas = CITA.findAll(linea).map { it.groupValues[1] }
                .filter { Regex("^(ley|reglamento|opini)", RegexOption.IGNORE_CASE).containsMatchIn(TextUtil.norm(it.trim())) }
                .toList() + Regex("\"cita\"\\s*:\\s*\"([^\"]+)\"").findAll(linea).map { it.groupValues[1] }.toList()
            if (citas.isEmpty()) continue
            val textos = citas.map { it to textoCitado(repo, it) }
            textos.filter { it.second == null }.forEach { avisos.add("La cita «${it.first}» no corresponde a ningún texto cargado.") }
            val validos = textos.mapNotNull { it.second }
            if (validos.isEmpty()) continue
            val nums = validos.flatMap { numeros(it) }.toSet()
            CANT.findAll(linea).forEach { m ->
                val v = m.groupValues[1].replace(",", ".").toDoubleOrNull() ?: return@forEach
                if (v !in nums) avisos.add("«${m.value.trim()}» no aparece en ${citas.joinToString(", ")}. Verifique el plazo o porcentaje en el texto.")
            }
        }
        return avisos.toList()
    }
}
