package pe.contrataciones.asistente.ai

import org.json.JSONArray
import org.json.JSONObject
import pe.contrataciones.asistente.data.Item
import pe.contrataciones.asistente.data.Opinion
import pe.contrataciones.asistente.data.Repo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Arma la consulta a Claude con los fragmentos de la Ley y el Reglamento recuperados en el
 * teléfono, y atiende las herramientas (buscar_normativa, leer_articulo, buscar_opiniones)
 * para que Claude pueda leer artículos adicionales antes de responder.
 */
class Assistant(private val repo: Repo) {

    data class Result(val text: String, val used: List<Item>, val ops: List<Opinion>, val avisos: List<String> = emptyList())

    private fun clip(s: String, n: Int) = if (s.length > n) s.take(n) + " […]" else s

    private fun systemPrompt(withViz: Boolean): String {
        val hoy = SimpleDateFormat("d 'de' MMMM 'de' yyyy", Locale("es", "PE")).format(Date())
        val docs = repo.normas.joinToString("\n") { "- ${it.corto}: ${it.nombre} (texto actualizado al ${it.vigenteAl}; fuente: ${it.fuente})" }
        val viz = if (!withViz) "" else """
7. GRÁFICOS: cuando ayuden a entender (procedimientos con pasos y plazos, secuencias, porcentajes o límites), incluye UN gráfico como bloque de código con una de estas etiquetas y JSON válido, justo después de la respuesta breve:
   ```linea  → {"titulo":"…","hitos":[{"momento":"Día 0","titulo":"…","detalle":"…","responsable":"…","cita":"Reglamento, art. 194.2 d)"}]}
   ```flujo  → {"titulo":"…","pasos":[{"actor":"Contratista","accion":"…","plazo":"15 días","cita":"Reglamento, art. 194.2 d)","alternativa":"Si no se aprueba: …"}]}
   ```barras → {"titulo":"…","unidad":"%","items":[{"etiqueta":"…","valor":15,"cita":"Ley, art. 64.3"}]}
   Usa solo datos que consten en los fragmentos (citas sin corchetes dentro del JSON). Máximo 10 elementos. Si no hay datos suficientes, no incluyas gráfico."""
        return """Eres un asistente técnico-legal especializado en la normativa peruana de contratación pública. Respondes a funcionarios municipales y profesionales (ingenieros, abogados, compradores públicos) sobre la Ley N.° 32069, Ley General de Contrataciones Públicas, su Reglamento y las opiniones de la Dirección Técnico Normativa (DTN) del OECE.

Fecha de hoy: $hoy.
Textos normativos disponibles:
$docs

REGLAS OBLIGATORIAS
1. Basa tu respuesta ÚNICAMENTE en los fragmentos normativos y opiniones entregados o que obtengas con las herramientas. Si un dato no aparece, búscalo con las herramientas; si aun así no aparece, dilo expresamente ("No encontré en los textos cargados…").
2. Cita cada afirmación entre corchetes con este formato exacto: [Ley, art. 63.1], [Reglamento, art. 194.2 d)], [Reglamento, Cuarta Disposición Complementaria Transitoria] u [Opinión D000092-2026-OECE-DTN]. Nunca inventes números de artículo, plazos, porcentajes ni opiniones.
3. Distingue la norma de la opinión: la norma obliga; las opiniones del OECE interpretan con carácter general. Si una opinión analiza la normativa anterior (Ley 30225), adviértelo.
4. Si la pregunta describe un caso concreto, explica qué dice la normativa y qué debe verificarse, sin dictamen definitivo; recomienda revisar bases, contrato y normativa vigente a la fecha del hecho.
5. Responde en español claro, en Markdown: **Respuesta breve** (2-4 líneas) · **Fundamento normativo** (viñetas con plazos, requisitos y responsables) · **Opiniones del OECE relacionadas** (si las hay) · **Precisiones**. No uses tablas.
6. Sé completo pero sin relleno.$viz"""
    }

    private fun artBlock(it: Item, max: Int) =
        "### [${repo.label(it)}] ${repo.title(it)}" + (if (it.u.isNotBlank()) "\n(Ubicación: ${it.u})" else "") + "\n" + clip(it.x, max)

    private fun opBlock(o: Opinion) =
        "### [Opinión ${o.numero}] ${o.fechaTexto.ifBlank { o.fecha }}\nSolicitante: ${o.solicitante.ifBlank { "—" }}\nAsunto: ${o.asunto}\n" +
            "Normativa analizada: ${o.normativa}\nCriterio: ${o.criterio}\nArtículos citados: ${o.articulos.joinToString("; ")}"

    private fun questionTurn(q: String, arts: List<Item>, ops: List<Opinion>): String {
        val sb = StringBuilder()
        if (arts.isNotEmpty()) {
            sb.append("FRAGMENTOS NORMATIVOS RECUPERADOS (los más relevantes según la búsqueda; pueden no ser suficientes):\n\n")
            sb.append(arts.mapIndexed { i, a -> artBlock(a, if (i < 4) 4500 else 2200) }.joinToString("\n\n"))
        } else sb.append("FRAGMENTOS NORMATIVOS: la búsqueda inicial no encontró coincidencias.")
        if (ops.isNotEmpty()) sb.append("\n\nOPINIONES DEL OECE REGISTRADAS (resúmenes):\n\n").append(ops.joinToString("\n\n") { opBlock(it) })
        sb.append("\n\nPuedes usar las herramientas buscar_normativa, leer_articulo y buscar_opiniones para leer artículos que se mencionan pero no están arriba (por ejemplo, remisiones a otros artículos) antes de responder.")
        sb.append("\n\nPREGUNTA DEL USUARIO:\n").append(q)
        return sb.toString()
    }

    private fun tools(): JSONArray = JSONArray()
        .put(JSONObject().put("name", "buscar_normativa")
            .put("description", "Busca por palabras clave en la Ley 32069 y su Reglamento. Devuelve hasta 8 artículos con un extracto.")
            .put("input_schema", JSONObject().put("type", "object")
                .put("properties", JSONObject()
                    .put("consulta", JSONObject().put("type", "string").put("description", "Palabras clave"))
                    .put("norma", JSONObject().put("type", "string").put("description", "'ley', 'reglamento' o vacío para ambas")))
                .put("required", JSONArray().put("consulta"))))
        .put(JSONObject().put("name", "leer_articulo")
            .put("description", "Devuelve el texto completo de un artículo o disposición. norma: 'ley' o 'reglamento'. numero: número del artículo (ej. '194') o nombre de la disposición (ej. 'Cuarta Disposición Complementaria Transitoria').")
            .put("input_schema", JSONObject().put("type", "object")
                .put("properties", JSONObject()
                    .put("norma", JSONObject().put("type", "string"))
                    .put("numero", JSONObject().put("type", "string")))
                .put("required", JSONArray().put("norma").put("numero"))))
        .put(JSONObject().put("name", "buscar_opiniones")
            .put("description", "Busca entre las opiniones de la Dirección Técnico Normativa del OECE registradas. Devuelve número, fecha, asunto, criterio resumido y artículos citados.")
            .put("input_schema", JSONObject().put("type", "object")
                .put("properties", JSONObject().put("consulta", JSONObject().put("type", "string")))
                .put("required", JSONArray().put("consulta"))))

    private fun runTool(name: String, input: JSONObject, used: MutableSet<Item>, onStep: (String) -> Unit): String {
        when (name) {
            "buscar_normativa" -> {
                val q = input.optString("consulta")
                onStep("Buscando: $q")
                val nk = repo.normaKey(input.optString("norma"))
                val arr = JSONArray()
                repo.searchItems(q, 8, nk).forEach {
                    arr.put(JSONObject().put("cita", repo.label(it)).put("titulo", repo.title(it)).put("extracto", clip(it.x, 500)))
                }
                return arr.toString()
            }
            "leer_articulo" -> {
                val nk = repo.normaKey(input.optString("norma"))
                    ?: throw IllegalArgumentException("Norma no reconocida. Use 'ley' o 'reglamento'.")
                val num = input.optString("numero").trim()
                val encontrado: Item? = if (Regex("disposici|final|transitori|modificatori|derogatori", RegexOption.IGNORE_CASE).containsMatchIn(num))
                    repo.findDisposicion(nk, num)
                else Regex("(\\d{1,3}(?:-?[A-Z])?)", RegexOption.IGNORE_CASE).find(num)?.let { m -> repo.getArticle(nk, m.groupValues[1]) }
                val item = encontrado ?: throw IllegalArgumentException("No se encontró $num en ${repo.normaById(nk).corto}.")
                onStep("Leyendo ${repo.label(item)}")
                used.add(item)
                return JSONObject().put("cita", repo.label(item)).put("titulo", repo.title(item)).put("texto", clip(item.x, 9000)).toString()
            }
            "buscar_opiniones" -> {
                val q = input.optString("consulta")
                onStep("Opiniones: $q")
                val arr = JSONArray()
                repo.searchOps(q, 5).forEach {
                    arr.put(JSONObject().put("numero", it.numero).put("fecha", it.fechaTexto).put("asunto", it.asunto)
                        .put("criterio", clip(it.criterio, 900)).put("articulos", JSONArray(it.articulos)).put("normativa", it.normativa))
                }
                return arr.toString()
            }
        }
        throw IllegalArgumentException("Herramienta desconocida: $name")
    }

    private fun msg(role: String, text: String) = JSONObject().put("role", role).put("content", text)

    /**
     * @param history pares (pregunta, respuesta) anteriores, del más antiguo al más reciente.
     */
    suspend fun ask(
        api: ClaudeApi,
        history: List<Pair<String, String>>,
        q: String,
        withOps: Boolean,
        withViz: Boolean,
        onStep: (String) -> Unit
    ): Result {
        val (arts, ops) = repo.retrieve(q, withOps)
        val used = LinkedHashSet(arts)
        val messages = JSONArray()
        history.takeLast(3).forEach { (u, a) -> messages.put(msg("user", u)); messages.put(msg("assistant", a)) }
        messages.put(msg("user", questionTurn(q, arts, ops)))
        val body = JSONObject()
            .put("max_tokens", 8000)
            .put("system", systemPrompt(withViz))
            .put("tools", tools())
            .put("messages", messages)

        var resp = api.create(body)
        var rounds = 0
        while (resp.optString("stop_reason") == "tool_use" && rounds < 6) {
            rounds++
            val content = resp.getJSONArray("content")
            // Se devuelve el contenido completo (incluidos los bloques de razonamiento) tal como llegó.
            messages.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") != "tool_use") continue
                val out = try {
                    runTool(b.getString("name"), b.optJSONObject("input") ?: JSONObject(), used, onStep)
                } catch (e: Exception) {
                    "Error: ${e.message}"
                }
                results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
            }
            messages.put(JSONObject().put("role", "user").put("content", results))
            body.put("messages", messages)
            resp = api.create(body)
        }
        val text = resp.textOf().ifBlank { "No se obtuvo respuesta. Intente con una pregunta más concreta." }
        return Result(text, used.toList(), ops, Verificador.revisar(repo, text))
    }
}
