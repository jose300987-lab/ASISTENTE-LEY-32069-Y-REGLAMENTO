package pe.contrataciones.asistente.data

import android.content.Context

/** Ajustes guardados en el teléfono. La clave de la API queda solo en este dispositivo. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lgcp", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v.trim()).apply()

    /** claude-sonnet-5-5 (recomendado) | claude-haiku-5-5 (económico) | claude-opus-5-5 (máximo) */
    var model: String
        get() = sp.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) = sp.edit().putString("model", v).apply()

    /** off | breve | full */
    var voz: String
        get() = sp.getString("voz", "off") ?: "off"
        set(v) = sp.edit().putString("voz", v).apply()

    var graficos: Boolean
        get() = sp.getBoolean("graficos", true)
        set(v) = sp.edit().putBoolean("graficos", v).apply()

    var incluirOpiniones: Boolean
        get() = sp.getBoolean("ops", true)
        set(v) = sp.edit().putBoolean("ops", v).apply()

    /** off | diaria | semanal */
    var autoUpdate: String
        get() = sp.getString("auto", "semanal") ?: "semanal"
        set(v) = sp.edit().putString("auto", v).apply()

    var ultimaRevision: String
        get() = sp.getString("ultimaRevision", "") ?: ""
        set(v) = sp.edit().putString("ultimaRevision", v).apply()

    var resumenRevision: String
        get() = sp.getString("resumenRevision", "") ?: ""
        set(v) = sp.edit().putString("resumenRevision", v).apply()

    /** Ids de fragmentos marcados como favoritos. */
    var favoritos: Set<Int>
        get() = (sp.getString("favs", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()
        set(v) = sp.edit().putString("favs", v.joinToString(",")).apply()
}
