package pe.contrataciones.asistente.data

import java.text.Normalizer
import kotlin.math.ln

object TextUtil {
    private val STOP = (
        "a al ante bajo con contra de del desde durante e el en entre hacia hasta la las le les lo los mediante o para " +
        "por que se segun sin sobre su sus tras u un una uno unos unas y es son ser sera esta este esto estos estas ese esa " +
        "eso cual cuales como cuando donde quien mas muy ya no si ni puede pueden debe deben dicho dicha otro otra otros " +
        "otras cada todo toda todos todas caso casos forma manera hay tiene tienen"
    ).split(" ").toSet()

    private val MARKS = Regex("\\p{Mn}+")
    private val WORD = Regex("[a-z0-9]+")

    fun norm(s: String): String =
        MARKS.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD), "")

    fun stem(word: String): String {
        var t = word
        if (t.first().isDigit()) return t
        if (t.length > 5 && t.endsWith("es")) t = t.dropLast(2)
        else if (t.length > 3 && t.endsWith("s")) t = t.dropLast(1)
        return if (t.length > 8) t.take(8) else t
    }

    fun tokens(s: String): List<String> =
        WORD.findAll(norm(s)).map { it.value }
            .filter { it.length > 1 && it !in STOP }
            .map { stem(it) }
            .toList()
}

/** Búsqueda por relevancia (BM25), la misma que usa la versión web. */
class Bm25<T>(private val docs: List<T>, fields: (T) -> List<String>) {
    private val tfs: List<Map<String, Int>>
    private val lens: IntArray
    private val df = HashMap<String, Int>()
    private val avg: Double

    init {
        val tf = ArrayList<Map<String, Int>>(docs.size)
        val l = IntArray(docs.size)
        var total = 0L
        docs.forEachIndexed { i, d ->
            val toks = fields(d)
            val m = HashMap<String, Int>()
            for (t in toks) m[t] = (m[t] ?: 0) + 1
            tf.add(m)
            l[i] = toks.size
            total += toks.size
            for (k in m.keys) df[k] = (df[k] ?: 0) + 1
        }
        tfs = tf
        lens = l
        avg = if (docs.isEmpty()) 1.0 else total.toDouble() / docs.size
    }

    fun search(q: String, k: Int = 8, filter: ((T) -> Boolean)? = null): List<T> {
        val qt = TextUtil.tokens(q).distinct()
        if (qt.isEmpty()) return emptyList()
        val n = docs.size
        val res = ArrayList<Pair<Double, Int>>()
        for (i in docs.indices) {
            if (filter != null && !filter(docs[i])) continue
            var s = 0.0
            var hit = 0
            for (t in qt) {
                val f = tfs[i][t] ?: continue
                hit++
                val d = df[t] ?: 1
                val idf = ln(1 + (n - d + 0.5) / (d + 0.5))
                s += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * lens[i] / avg))
            }
            if (s > 0) res.add(s * (0.6 + 0.4 * hit / qt.size) to i)
        }
        return res.sortedByDescending { it.first }.take(k).map { docs[it.second] }
    }
}
