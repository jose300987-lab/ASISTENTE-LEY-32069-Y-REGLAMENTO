package pe.contrataciones.asistente.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import pe.contrataciones.asistente.data.Grupo
import pe.contrataciones.asistente.data.Item
import pe.contrataciones.asistente.data.Opinion

private val AMBAR = Color(0xFF9A5B13)
private val SERIF = FontFamily.Serif

@Composable
fun AppRoot(vm: AppVM) {
    AppTheme {
        if (!vm.cargado) {
            Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("Cargando la Ley y el Reglamento…")
                }
            }
            return@AppTheme
        }
        Scaffold(
            topBar = { Cabecera(vm) },
            bottomBar = {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = vm.tab == t,
                            onClick = { vm.tab = t },
                            icon = { Text(t.icono, fontSize = 20.sp) },
                            label = { Text(t.titulo, fontSize = 11.sp) }
                        )
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (vm.tab) {
                    Tab.BUSCAR -> BuscarScreen(vm)
                    Tab.FICHAS -> FichasScreen(vm)
                    Tab.NORMAS -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("ley" to "📘 Ley 32069", "reglamento" to "📗 Reglamento").forEach { (id, t) ->
                                FilterChip(selected = vm.normaSel == id, onClick = { vm.normaSel = id }, label = { Text(t) })
                            }
                        }
                        NormaScreen(vm, vm.normaSel)
                    }
                    Tab.OPINIONES -> OpinionesScreen(vm)
                    Tab.AJUSTES -> AjustesScreen(vm)
                }
            }
        }
        vm.verFicha?.let { FichaScreen(vm, it) }
        if (vm.chatAbierto) VentanaChat(vm)
        vm.verItem?.let { VisorArticulo(vm, it) }
        vm.verOpinion?.let { VisorOpinion(vm, it) }
    }
}

@Composable
private fun Cabecera(vm: AppVM) {
    Surface(color = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("§", fontFamily = SERIF, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Asistente de Contrataciones Públicas", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("Ley N.° 32069 · Reglamento · Texto oficial", fontSize = 12.sp)
            }
            if (vm.hayClave()) {
                TextButton(onClick = { vm.chatAbierto = true }) {
                    Text("✨ IA", color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }
}

// ============================ EXPLICAR CON IA (opcional) ============================

@Composable
private fun VentanaChat(vm: AppVM) {
    Dialog(onDismissRequest = { vm.chatAbierto = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.chatAbierto = false }) { Text("← Volver") }
                    Text("Explicar con IA", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (vm.chat.isNotEmpty()) TextButton(onClick = { vm.nuevaConversacion() }) { Text("Nueva") }
                }
                Box(Modifier.weight(1f)) { ChatScreen(vm) }
            }
        }
    }
}

private val SUGERENCIAS = listOf(
    "¿Cuál es el procedimiento y los plazos para aprobar una prestación adicional de obra?",
    "¿Cuándo procede contratar el saldo de obra por contratación directa?",
    "¿Cómo se aplica la penalidad por mora y cómo la justifica el contratista?",
    "¿En qué plazo debe pagarse una valorización de obra si tiene observaciones?",
    "¿Cómo se acredita la experiencia similar del postor?",
    "¿Qué controversias resuelve la Junta de Prevención y Resolución de Disputas?"
)

@Composable
private fun ChatScreen(vm: AppVM) {
    val ctx = LocalContext.current
    var input by rememberSaveable { mutableStateOf("") }
    val lista = rememberLazyListState()
    val dictado = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) {
            if (vm.prefs.voz != "off") { vm.enviar(t); input = "" } else input = (input + " " + t).trim()
        }
    }
    val total = vm.chat.size + (if (vm.chat.isEmpty()) 1 else 0) + (if (vm.ocupado) 1 else 0)
    LaunchedEffect(vm.chat.size, vm.ocupado, vm.pasos.size) {
        if (total > 0) lista.animateScrollToItem(total - 1)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = lista,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (vm.chat.isEmpty()) item { Bienvenida(vm) }
            items(vm.chat) { m -> Burbuja(vm, m) }
            if (vm.ocupado) item { Pensando(vm.pasos) }
        }
        Surface(tonalElevation = 3.dp) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Escriba o dicte su consulta…") },
                    maxLines = 5,
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.width(6.dp))
                FilledTonalIconButton(onClick = {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga su consulta")
                    }
                    try { dictado.launch(i) } catch (e: ActivityNotFoundException) {
                        Toast.makeText(ctx, "Este teléfono no tiene reconocimiento de voz instalado.", Toast.LENGTH_LONG).show()
                    }
                }, enabled = !vm.ocupado) { Text("🎤", fontSize = 18.sp) }
                Spacer(Modifier.width(6.dp))
                if (vm.ocupado) {
                    OutlinedButton(onClick = { vm.detener() }) { Text("Detener") }
                } else {
                    Button(onClick = { vm.enviar(input); input = "" }, enabled = input.isNotBlank()) { Text("Enviar") }
                }
            }
        }
    }
}

@Composable
private fun Bienvenida(vm: AppVM) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Explicación con IA", fontFamily = SERIF, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("La IA redacta usando solo los numerales recuperados de la Ley y el Reglamento. Cada respuesta se revisa " +
                "automáticamente: si cita un artículo que no existe o un plazo que no figura en el artículo citado, se le avisa.", fontSize = 13.sp)
            Text("Las respuestas se basan solo en los textos oficiales cargados (Ley al ${vm.repo.normaById("ley").vigenteAl}, " +
                "Reglamento al ${vm.repo.normaById("reglamento").vigenteAl}) y en las opiniones del OECE registradas. " +
                "Toque una cita para leer el artículo.", fontSize = 14.sp, color = Color.Gray)
            if (!vm.hayClave()) {
                Surface(color = AMBAR.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Para usar el chat necesita una clave de la API de Claude.", fontSize = 14.sp)
                        TextButton(onClick = { vm.chatAbierto = false; vm.tab = Tab.AJUSTES }) { Text("Ir a Ajustes") }
                    }
                }
            }
            SUGERENCIAS.forEach { s ->
                Surface(
                    shape = RoundedCornerShape(50),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33000000)),
                    modifier = Modifier.clickable { vm.enviar(s) }
                ) { Text(s, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 14.sp) }
            }
        }
    }
}

@Composable
private fun Burbuja(vm: AppVM, m: ChatMsg) {
    if (m.user) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(14.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                Text(m.text, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onPrimary)
            }
        }
        return
    }
    val clip = LocalClipboardManager.current
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (m.error) Text(m.text, color = MaterialTheme.colorScheme.error)
            else RichText(m.text) { vm.abrirCita(it) }
            if (!m.error && !m.user) {
                if (m.avisos.isEmpty()) Text("✓ Citas y plazos verificados contra los textos cargados", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                else Surface(color = MaterialTheme.colorScheme.error.copy(alpha = 0.08f), shape = RoundedCornerShape(8.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        Text("⚠ Revise antes de usar:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                        m.avisos.take(6).forEach { Text("• $it", fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            if (!m.error) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { if (vm.hablando) vm.callar() else vm.escuchar(m.text) }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                        Text(if (vm.hablando) "⏹ Detener" else "🔊 Escuchar", fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { clip.setText(AnnotatedString(m.text)) }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                        Text("Copiar", fontSize = 13.sp)
                    }
                }
            }
            if (m.used.isNotEmpty() || m.ops.isNotEmpty()) {
                Text("Textos consultados", fontSize = 12.sp, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(m.used) { it -> Box(Modifier.clickable { vm.verItem = it }) { Pastilla(vm.repo.label(it), MaterialTheme.colorScheme.primary) } }
                    items(m.ops) { o -> Box(Modifier.clickable { vm.verOpinion = o }) { Pastilla("Opinión ${o.numero}", AMBAR) } }
                }
            }
        }
    }
}

@Composable
private fun Pensando(pasos: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Analizando la normativa…", color = Color.Gray)
            }
            pasos.takeLast(4).forEach { Text("· $it", fontSize = 12.sp, color = Color.Gray) }
        }
    }
}

// ============================ LEY / REGLAMENTO ============================

@Composable
private fun NormaScreen(vm: AppVM, normaId: String) {
    val norma = vm.repo.normaById(normaId)
    var q by rememberSaveable(normaId) { mutableStateOf("") }
    val grupos = remember(normaId) { vm.repo.grupos(normaId) }
    val abiertos = remember(normaId) { mutableStateMapOf<String, Boolean>() }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(norma.nombre, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Texto actualizado al ${norma.vigenteAl} · ${norma.fuente}", fontSize = 12.sp, color = Color.Gray)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("Buscar: palabra o n.° de artículo") }, shape = RoundedCornerShape(12.dp)
            )
        }
        if (q.isNotBlank()) {
            val res = remember(q, normaId) {
                val num = Regex("^(?:art[íi]culo|art\\.?)?\\s*(\\d{1,3}(?:-?[A-Za-z])?)º?$", RegexOption.IGNORE_CASE).find(q.trim())
                val exact = num?.let { vm.repo.getArticle(normaId, it.groupValues[1]) }
                if (exact != null) listOf(exact) else vm.repo.searchItems(q, 30, normaId)
            }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (res.isEmpty()) item { Text("Sin resultados.", color = Color.Gray) }
                items(res) { it -> ResultadoItem(vm, it) }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (g in grupos) {
                    item(key = g.key) {
                        TarjetaGrupo(g, abiertos[g.key] == true, { abiertos[g.key] = abiertos[g.key] != true }) { vm.verItem = it }
                    }
                }
            }
        }
    }
}

private fun rango(arts: List<Item>): String = when {
    arts.isEmpty() -> ""
    arts.size == 1 -> "Artículo ${arts[0].n}º"
    else -> "Artículos ${arts.first().n}º al ${arts.last().n}º"
}

@Composable
private fun TarjetaGrupo(g: Grupo, abierto: Boolean, toggle: () -> Unit, abrir: (Item) -> Unit) {
    val arts = g.items.filter { it.t == "art" }
    val sub = if (arts.isNotEmpty()) rango(arts) else "${g.items.size} " + when (g.key) { "disp" -> "disposiciones"; "anexo" -> "secciones"; else -> "fragmentos" }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().clickable { toggle() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (abierto) "⌃" else "⌄", color = Color.Gray, modifier = Modifier.width(24.dp))
            Column {
                Text(g.cabecera, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (g.nombre.isNotBlank()) Text(g.nombre, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(sub, fontSize = 15.sp, color = Color.Gray)
            }
        }
        if (abierto) {
            HorizontalDivider()
            var ultimoSub: String? = null
            Column(Modifier.padding(vertical = 4.dp)) {
                for (it in g.items) {
                    val subH = when (it.t) {
                        "art" -> listOf(it.ct, it.cn).filter { s -> s.isNotBlank() }.joinToString(" · ")
                        "disp" -> it.u
                        else -> ""
                    }
                    if (subH.isNotBlank() && subH != ultimoSub) {
                        Text(subH.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 2.dp))
                        ultimoSub = subH
                    }
                    Row(Modifier.fillMaxWidth().clickable { abrir(it) }.padding(start = 40.dp, end = 14.dp, top = 7.dp, bottom = 7.dp)) {
                        if (it.t == "art") {
                            Text("Art. ${it.n}º ", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                            Text(it.ti, fontSize = 14.sp)
                        } else {
                            Text(if (it.t == "disp") it.n + " · " + it.x.lineSequence().firstOrNull().orEmpty().take(80) else it.ti, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultadoItem(vm: AppVM, it: Item) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth().clickable { vm.verItem = it }) {
        Column(Modifier.padding(12.dp)) {
            Text(vm.repo.label(it) + if (it.tt.isNotBlank()) " · ${it.tt}" else "", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Text(vm.repo.title(it), fontSize = 14.sp)
            Text(it.x.take(220), fontSize = 12.sp, color = Color.Gray, maxLines = 3)
        }
    }
}

@Composable
private fun VisorArticulo(vm: AppVM, it: Item) {
    val mismos = remember(it.norma) { vm.repo.items.filter { x -> x.norma == it.norma } }
    val pos = mismos.indexOf(it)
    val prev = mismos.getOrNull(pos - 1)
    val next = mismos.getOrNull(pos + 1)
    val clip = LocalClipboardManager.current
    val marca = vm.resaltar?.takeIf { f -> f.item == it.id }
    val rango = remember(it.id, marca?.id) { marca?.let { f -> rangoEn(it.x, f.texto) } }
    val scroll = rememberScrollState()
    var topTexto by remember(it.id) { mutableStateOf(0) }
    var layout by remember(it.id) { mutableStateOf<androidx.compose.ui.text.TextLayoutResult?>(null) }
    LaunchedEffect(rango, layout, topTexto) {
        val l = layout ?: return@LaunchedEffect
        val r = rango ?: return@LaunchedEffect
        val y = l.getLineTop(l.getLineForOffset(r.first.coerceIn(0, it.x.length))).toInt()
        scroll.animateScrollTo((topTexto + y - 80).coerceAtLeast(0))
    }
    val cerrar = { vm.verItem = null; vm.resaltar = null }
    Dialog(onDismissRequest = cerrar, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = cerrar) { Text("← Volver") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { vm.voz.hablar(vm.repo.title(it) + ". " + it.x, "full") }) { Text("🔊") }
                    TextButton(onClick = {
                        clip.setText(AnnotatedString(marca?.let { f -> vm.repo.textoParaCopiar(f) } ?: (vm.repo.title(it) + "\n" + it.x)))
                    }) { Text(if (marca != null) "Copiar ${marca.num.ifBlank { "" }}${if (marca.lit.isNotBlank()) " " + marca.lit + ")" else ""}" else "Copiar") }
                }
                Column(Modifier.weight(1f).verticalScroll(scroll).padding(horizontal = 18.dp)) {
                    Text(vm.repo.normaById(it.norma).nombre.uppercase(), fontSize = 11.sp, color = Color.Gray)
                    Text(vm.repo.title(it), fontFamily = SERIF, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 6.dp))
                    if (it.u.isNotBlank()) Text(it.u, fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    SelectionContainer(Modifier.onGloballyPositioned { c -> topTexto = c.positionInParent().y.toInt() }) {
                        val anotado = remember(it.id, rango) {
                            androidx.compose.ui.text.buildAnnotatedString {
                                append(it.x)
                                rango?.let { r -> addStyle(androidx.compose.ui.text.SpanStyle(background = Color(0x55F2C14E)), r.first, r.last + 1) }
                            }
                        }
                        Text(anotado, fontFamily = SERIF, fontSize = 16.sp, lineHeight = 25.sp, onTextLayout = { l -> layout = l })
                    }
                    if (marca?.nota?.isNotBlank() == true) Text("Modificación: ${marca.nota}", fontSize = 12.sp, color = AMBAR, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(16.dp))
                    if (vm.hayClave()) Button(onClick = {
                        val q = if (it.t == "art") "Explique el artículo ${it.n} de${if (it.norma == "ley") " la Ley" else "l Reglamento"}: alcances, plazos y obligaciones."
                        else "Explique la ${it.ti}${if (it.norma == "ley") " de la Ley" else " del Reglamento"}."
                        vm.preguntarSobre(q)
                    }) { Text("✨ Explicar con IA") }
                    Spacer(Modifier.height(16.dp))
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { vm.resaltar = null; vm.verItem = prev }, enabled = prev != null) {
                        Text("← " + (prev?.let { p -> if (p.t == "art") "Art. ${p.n}" else "Anterior" } ?: ""))
                    }
                    TextButton(onClick = { vm.resaltar = null; vm.verItem = next }, enabled = next != null) {
                        Text((next?.let { n -> if (n.t == "art") "Art. ${n.n}" else "Siguiente" } ?: "") + " →")
                    }
                }
            }
        }
    }
}

// ============================ OPINIONES ============================

@Composable
private fun OpinionesScreen(vm: AppVM) {
    var q by rememberSaveable { mutableStateOf("") }
    val lista = remember(q, vm.version) {
        if (q.isBlank()) vm.repo.opiniones
        else (vm.repo.opiniones.filter { it.numero.contains(q.trim(), true) } + vm.repo.searchOps(q, 40)).distinct()
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true, shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(12.dp), placeholder = { Text("Tema, artículo o número de opinión") }
        )
        Text("${vm.repo.opiniones.size} opiniones de la Dirección Técnico Normativa del OECE", fontSize = 12.sp, color = Color.Gray,
            modifier = Modifier.padding(horizontal = 14.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(lista) { o ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().clickable { vm.verOpinion = o }) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Opinión ${o.numero}", color = AMBAR, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            if (o.agregadaPorActualizacion) Pastilla("nueva", MaterialTheme.colorScheme.primary)
                        }
                        Text(o.fechaTexto, fontSize = 12.sp, color = Color.Gray)
                        Text(o.asunto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(o.criterio, fontSize = 12.sp, color = Color.Gray, maxLines = 3)
                    }
                }
            }
        }
    }
}

@Composable
private fun VisorOpinion(vm: AppVM, o: Opinion) {
    val uri = LocalUriHandler.current
    Dialog(onDismissRequest = { vm.verOpinion = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.padding(8.dp)) { TextButton(onClick = { vm.verOpinion = null }) { Text("← Volver") } }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("OPINIÓN DTN · OECE", fontSize = 11.sp, color = Color.Gray)
                    Text("N.° ${o.numero}", fontFamily = SERIF, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text(listOf(o.fechaTexto, o.solicitante).filter { it.isNotBlank() }.joinToString(" · "), fontSize = 13.sp, color = Color.Gray)
                    Text(o.asunto, fontWeight = FontWeight.SemiBold)
                    SelectionContainer { Text(o.criterio, fontFamily = SERIF, fontSize = 16.sp, lineHeight = 25.sp) }
                    if (o.articulos.isNotEmpty()) Text("Artículos: " + o.articulos.joinToString("; "), fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    if (!o.normativa.contains("32069")) Pastilla(o.normativa, AMBAR)
                    if (!o.verificado) Text("Resumen elaborado a partir de lo publicado; confirme el texto íntegro en la fuente oficial.", fontSize = 12.sp, color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (o.url.isNotBlank()) OutlinedButton(onClick = { runCatching { uri.openUri(o.url) } }) { Text("Ver fuente oficial") }
                        if (vm.hayClave()) Button(onClick = { vm.preguntarSobre("¿Qué criterio establece la Opinión ${o.numero} y qué artículos interpreta?") }) { Text("Preguntar") }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

// ============================ AJUSTES ============================

@Composable
private fun AjustesScreen(vm: AppVM) {
    val uri = LocalUriHandler.current
    var clave by remember { mutableStateOf(vm.prefs.apiKey) }
    var guardada by remember { mutableStateOf(false) }
    var modelo by remember { mutableStateOf(vm.prefs.model) }
    var voz by remember { mutableStateOf(vm.prefs.voz) }
    var graficos by remember { mutableStateOf(vm.prefs.graficos) }
    var ops by remember { mutableStateOf(vm.prefs.incluirOpiniones) }
    var auto by remember { mutableStateOf(vm.prefs.autoUpdate) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Seccion("Explicar con IA (opcional)") {
            Text("La app funciona completa sin clave: búsqueda literal, trámites, normas y opiniones. Si ingresa una clave de la API de Claude (pago por uso), " +
                "aparece el botón ✨ para pedir explicaciones redactadas solo con los textos cargados y verificadas automáticamente. " +
                "Cree su clave en console.anthropic.com → API Keys. Se guarda solo en este teléfono; déjela vacía para no usar IA.", fontSize = 13.sp, color = Color.Gray)
            OutlinedTextField(value = clave, onValueChange = { clave = it; guardada = false }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), placeholder = { Text("sk-ant-…") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { vm.prefs.apiKey = clave; guardada = true }) { Text("Guardar") }
                TextButton(onClick = { runCatching { uri.openUri("https://console.anthropic.com/settings/keys") } }) { Text("Obtener clave") }
                if (guardada) Text("Guardada ✓", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            }
        }
        Seccion("Modelo") {
            listOf(
                "claude-sonnet-5-5" to "Sonnet 5.5 — recomendado (equilibrio calidad/costo)",
                "claude-haiku-5-5" to "Haiku 5.5 — más rápido y económico",
                "claude-opus-5-5" to "Opus 5.5 — análisis más profundo (más costoso)"
            ).forEach { (id, txt) -> Opcion(modelo == id, txt) { modelo = id; vm.prefs.model = id } }
        }
        Seccion("Respuesta con voz") {
            listOf("off" to "Desactivada", "breve" to "Leer solo la respuesta breve", "full" to "Leer la respuesta completa")
                .forEach { (id, txt) -> Opcion(voz == id, txt) { voz = id; vm.prefs.voz = id; if (id == "off") vm.callar() } }
            Text("Con la voz activada, al dictar con 🎤 la consulta se envía sola.", fontSize = 12.sp, color = Color.Gray)
        }
        Seccion("Respuestas") {
            Interruptor("Incluir gráficos (líneas de tiempo, flujos, barras)", graficos) { graficos = it; vm.prefs.graficos = it }
            Interruptor("Incluir opiniones del OECE", ops) { ops = it; vm.prefs.incluirOpiniones = it }
        }
        Seccion("Actualizaciones (solo fuentes oficiales)") {
            Text("Busca en gob.pe y El Peruano opiniones nuevas de la DTN, normas que modifiquen la Ley o el Reglamento y resoluciones del OECE. Requiere la clave de la API (cada búsqueda consume saldo).", fontSize = 13.sp, color = Color.Gray)
            listOf("off" to "Solo manual", "semanal" to "Automática cada semana", "diaria" to "Automática cada día")
                .forEach { (id, txt) -> Opcion(auto == id, txt) { auto = id; vm.cambiarAuto(id) } }
            val ult = remember(vm.version, vm.buscandoNovedades) { vm.prefs.ultimaRevision }
            Text("Última revisión: " + (ult.ifBlank { "nunca" }.replace("T", " ")), fontSize = 13.sp)
            Button(onClick = { vm.buscarNovedades() }, enabled = !vm.buscandoNovedades) {
                Text(if (vm.buscandoNovedades) "Buscando…" else "⟳ Buscar actualizaciones ahora")
            }
            if (vm.estadoNovedades.isNotBlank()) Text(vm.estadoNovedades, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
            val novs = remember(vm.version) { vm.repo.novedades }
            novs.forEach { n ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${n.tipo} · ${n.numero}" + if (n.fecha.isNotBlank()) " · ${n.fecha}" else "", fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, color = if (n.tipo == "Opinión") AMBAR else MaterialTheme.colorScheme.error)
                        Text(n.titulo, fontSize = 14.sp)
                        if (n.resumen.isNotBlank()) Text(n.resumen, fontSize = 12.sp, color = Color.Gray)
                        if (n.accion.isNotBlank()) Text(n.accion, fontSize = 12.sp, color = AMBAR)
                        if (n.url.isNotBlank()) TextButton(onClick = { runCatching { uri.openUri(n.url) } }) { Text("Ver fuente oficial") }
                    }
                }
            }
        }
        Seccion("Textos incluidos") {
            vm.repo.normas.forEach { Text("• ${it.nombre} — actualizado al ${it.vigenteAl} (${it.fuente})", fontSize = 13.sp) }
            Text("• ${vm.repo.opiniones.size} opiniones de la DTN del OECE", fontSize = 13.sp)
            Text("Herramienta de consulta: no reemplaza la revisión del texto oficial ni la opinión legal.", fontSize = 12.sp, color = Color.Gray)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Seccion(titulo: String, contenido: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(titulo, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            contenido()
        }
    }
}

@Composable
private fun Opcion(sel: Boolean, texto: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = sel, onClick = onClick)
        Text(texto, fontSize = 14.sp)
    }
}

@Composable
private fun Interruptor(texto: String, valor: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(texto, Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = valor, onCheckedChange = onChange)
    }
}

/** Posición del texto de un numeral dentro del artículo (tolera espacios y comillas distintas). */
internal fun rangoEn(articulo: String, fragmento: String): IntRange? {
    val lineas = fragmento.lines().map { it.trim().trim('"', '“', '”') }.filter { it.length > 3 }
    if (lineas.isEmpty()) return null
    val ini = articulo.indexOf(lineas.first().take(60)).takeIf { it >= 0 } ?: return null
    val ultima = lineas.last().takeLast(40)
    val fin = articulo.indexOf(ultima, ini).let { if (it >= 0) it + ultima.length - 1 else ini + lineas.first().length - 1 }
    return ini..fin.coerceAtMost(articulo.length - 1)
}
