package pe.contrataciones.asistente.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Claro = lightColorScheme(
    primary = Color(0xFF0F4C45),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EFEC),
    onPrimaryContainer = Color(0xFF0F4C45),
    secondary = Color(0xFF9A5B13),
    background = Color(0xFFF4F2EC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE3EFEC),
    error = Color(0xFFA33B2B)
)

private val Oscuro = darkColorScheme(
    primary = Color(0xFF5FB3A6),
    onPrimary = Color(0xFF0D1413),
    primaryContainer = Color(0xFF1F3532),
    onPrimaryContainer = Color(0xFFCFE8E3),
    secondary = Color(0xFFE0A35A),
    background = Color(0xFF141817),
    surface = Color(0xFF202625),
    surfaceVariant = Color(0xFF1F3532),
    error = Color(0xFFE07A68)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Oscuro else Claro, content = content)
}
