package pe.contrataciones.asistente

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import pe.contrataciones.asistente.ai.Updater
import pe.contrataciones.asistente.ui.AppRoot
import pe.contrataciones.asistente.ui.AppVM

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Revisión automática de novedades en fuentes oficiales (según Ajustes; semanal por defecto).
        Updater.schedule(applicationContext, vm.prefs.autoUpdate)
        setContent { AppRoot(vm) }
    }
}
