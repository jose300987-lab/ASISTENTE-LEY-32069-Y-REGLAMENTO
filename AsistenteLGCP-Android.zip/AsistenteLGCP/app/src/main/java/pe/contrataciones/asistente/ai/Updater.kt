package pe.contrataciones.asistente.ai

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import pe.contrataciones.asistente.data.Novedad
import pe.contrataciones.asistente.data.Opinion
import pe.contrataciones.asistente.data.Prefs
import pe.contrataciones.asistente.data.Repo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Busca, solo en páginas oficiales (gob.pe y elperuano.pe), opiniones nuevas de la DTN del OECE,
 * normas que modifiquen la Ley o el Reglamento y resoluciones relevantes del OECE.
 * Usa la herramienta de búsqueda web de la API de Claude con filtro de dominios.
 */
object Updater {

    private val OFICIALES = Regex("^https://([a-z0-9-]+\\.)*(gob\\.pe|elperuano\\.pe)(/|$)", RegexOption.IGNORE_CASE)

    data class Outcome(val nuevos: Int, val resumen: String)

    suspend fun run(api: ClaudeApi, repo: Repo, prefs: Prefs): Outcome {
        val ahora = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())
        val conocidas = repo.opiniones.joinToString(", ") { it.numero }
        val novs = repo.novedades.joinToString(", ") { it.numero }
        val ley = repo.normaById("ley").vigenteAl
        val reg = repo.normaById("reglamento").vigenteAl
        val prompt = """Hoy es ${ahora.take(10)}. Busca SOLO en fuentes oficiales del Estado peruano (gob.pe, incluido el OECE y el MEF, y El Peruano):
a) Opiniones de la Dirección Técnico Normativa del OECE (formato D000NNN-AAAA-OECE-DTN) que NO estén en esta lista: $conocidas.
b) Normas (leyes, decretos supremos, decretos legislativos) que modifiquen la Ley N.° 32069 publicadas después del $ley, o que modifiquen su Reglamento (D.S. N.° 009-2025-EF) publicadas después del $reg.
c) Resoluciones del OECE relevantes de los últimos 60 días (directivas, lineamientos, bases estándar, acuerdos de Sala Plena del Tribunal).
No repitas estas novedades ya registradas: ${novs.ifBlank { "(ninguna)" }}.

Responde ÚNICAMENTE con un objeto JSON, sin texto adicional:
{"opiniones":[{"numero":"","fecha":"AAAA-MM-DD","solicitante":"","asunto":"","normativa":"Ley 32069 y su Reglamento","criterio":"resumen fiel de las conclusiones con tus palabras, máx. 900 caracteres","articulos":["Reglamento art. 194.2"],"url":"https://www.gob.pe/..."}],
 "normas":[{"tipo":"Norma o Resolución","numero":"","fecha":"AAAA-MM-DD","titulo":"","resumen":"","url":"https://...","modifica":"ley | reglamento | ninguna"}]}
Incluye solo lo que hayas confirmado en una página oficial, con su URL oficial. No inventes números ni fechas. Si no hay novedades, devuelve listas vacías."""

        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject()
            .put("max_tokens", 6000)
            .put("tools", JSONArray().put(JSONObject()
                .put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 8)
                .put("allowed_domains", JSONArray().put("gob.pe").put("elperuano.pe"))))
            .put("messages", messages)

        var resp = api.create(body)
        var rounds = 0
        while (resp.optString("stop_reason") == "pause_turn" && rounds < 4) {
            rounds++
            messages.put(JSONObject().put("role", "assistant").put("content", resp.getJSONArray("content")))
            body.put("messages", messages)
            resp = api.create(body)
        }
        val txt = resp.textOf()
        val json = runCatching {
            JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1))
        }.getOrElse { throw IllegalStateException("La búsqueda no devolvió un resultado legible. Intente de nuevo más tarde.") }

        val newOps = ArrayList<Opinion>()
        val newNovs = ArrayList<Novedad>()
        json.optJSONArray("opiniones")?.let { arr ->
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val url = j.optString("url")
                val numero = j.optString("numero").trim().uppercase()
                if (numero.isBlank() || !OFICIALES.containsMatchIn(url)) continue
                val arts = j.optJSONArray("articulos")
                val fecha = j.optString("fecha")
                val op = Opinion(
                    numero, fecha, fechaTexto(fecha), j.optString("solicitante"), j.optString("asunto"),
                    j.optString("normativa", "Ley 32069 y su Reglamento"), j.optString("criterio"),
                    if (arts == null) emptyList() else (0 until arts.length()).map { arts.optString(it) },
                    url, verificado = false, agregadaPorActualizacion = true
                )
                newOps.add(op)
                newNovs.add(Novedad("Opinión", numero, fecha, op.asunto, op.criterio.take(220), url, "", ahora))
            }
        }
        json.optJSONArray("normas")?.let { arr ->
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val url = j.optString("url")
                if (j.optString("numero").isBlank() || !OFICIALES.containsMatchIn(url)) continue
                val modifica = j.optString("modifica").lowercase()
                val accion = when {
                    modifica.contains("regl") -> "Modifica el Reglamento: la app mostrará el texto anterior hasta que se instale una versión actualizada."
                    modifica.contains("ley") -> "Modifica la Ley: la app mostrará el texto anterior hasta que se instale una versión actualizada."
                    else -> ""
                }
                newNovs.add(Novedad(j.optString("tipo", "Norma"), j.optString("numero"), j.optString("fecha"),
                    j.optString("titulo"), j.optString("resumen"), url, accion, ahora))
            }
        }
        val n = repo.addUpdates(newOps, newNovs)
        val resumen = if (n == 0) "Sin novedades en fuentes oficiales." else "$n novedades nuevas registradas."
        prefs.ultimaRevision = ahora
        prefs.resumenRevision = resumen
        return Outcome(n, resumen)
    }

    private fun fechaTexto(iso: String): String = runCatching {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso)!!
        SimpleDateFormat("dd MMM. yyyy", Locale("es", "PE")).format(d)
    }.getOrDefault(iso)

    /** Programa (o cancela) la revisión automática según el ajuste del usuario. */
    fun schedule(ctx: Context, modo: String) {
        val wm = WorkManager.getInstance(ctx)
        if (modo == "off") { wm.cancelUniqueWork("actualizacion"); return }
        val dias = if (modo == "diaria") 1L else 7L
        val req = PeriodicWorkRequestBuilder<UpdateWorker>(dias, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork("actualizacion", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        if (prefs.apiKey.isBlank()) return Result.success()
        return try {
            val repo = Repo(applicationContext).also { it.load() }
            Updater.run(ClaudeApi(prefs.apiKey, prefs.model), repo, prefs)
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 2) Result.retry() else Result.success()
        }
    }
}
