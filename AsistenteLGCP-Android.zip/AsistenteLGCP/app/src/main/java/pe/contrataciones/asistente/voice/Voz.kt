package pe.contrataciones.asistente.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Lectura en voz alta en español (motor de voz del teléfono). */
class Voz(ctx: Context) {
    private var listo = false
    var hablando: ((Boolean) -> Unit)? = null
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
            listo = true
            val prefer = listOf(Locale("es", "PE"), Locale("es", "US"), Locale("es", "MX"), Locale("es", "ES"), Locale("es"))
            for (l in prefer) {
                val r = tts.setLanguage(l)
                if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) break
            }
            tts.setSpeechRate(1.02f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { hablando?.invoke(true) }
                override fun onDone(id: String?) { if (id == "ultimo") hablando?.invoke(false) }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { hablando?.invoke(false) }
            })
        }
    }

    fun disponible() = listo

    fun hablar(markdown: String, modo: String) {
        if (!listo) return
        detener()
        val partes = trozos(textoHablado(markdown, modo))
        partes.forEachIndexed { i, p ->
            tts.speak(p, TextToSpeech.QUEUE_ADD, null, if (i == partes.lastIndex) "ultimo" else "p$i")
        }
    }

    fun detener() {
        if (listo) tts.stop()
        hablando?.invoke(false)
    }

    fun cerrar() = tts.shutdown()

    companion object {
        /** Convierte la respuesta en texto natural para leer: quita Markdown, gráficos y lee las citas. */
        fun textoHablado(md: String, modo: String): String {
            var t = md.replace("\r", "").replace(Regex("```[\\s\\S]*?(```|$)"), " ")
            if (modo == "breve") {
                val corte = Regex("\\n(?=\\s*(?:#{1,4}\\s*|\\*\\*)\\s*Fundamento)", RegexOption.IGNORE_CASE).find(t)
                t = if (corte != null && corte.range.first > 40) t.substring(0, corte.range.first) else t.take(900)
            }
            t = t.replace(Regex("^\\s*(?:#{1,4}\\s*)?\\*\\*([^*\\n]+)\\*\\*\\s*:?\\s*$", RegexOption.MULTILINE), "$1.")
            t = t.replace(Regex("\\[(?:Ley|LGCP),\\s*art(?:[íi]culo|\\.)\\s*([\\d.]+)([^\\]]*)\\]", RegexOption.IGNORE_CASE)) {
                " (artículo ${it.groupValues[1]}${it.groupValues[2].replace(")", "")} de la Ley) " }
            t = t.replace(Regex("\\[(?:Reglamento|RLGCP),\\s*art(?:[íi]culo|\\.)\\s*([\\d.]+)([^\\]]*)\\]", RegexOption.IGNORE_CASE)) {
                " (artículo ${it.groupValues[1]}${it.groupValues[2].replace(")", "")} del Reglamento) " }
            t = t.replace(Regex("\\[(?:Ley|Reglamento),\\s*([^\\]]+)\\]", RegexOption.IGNORE_CASE)) { "(según la ${it.groupValues[1]})" }
            t = t.replace(Regex("\\[Opini[oó]n\\s*N?[°º]?\\s*D0*(\\d+)-(\\d{4})-OECE-DTN\\]", RegexOption.IGNORE_CASE)) {
                " (Opinión ${it.groupValues[1]} del ${it.groupValues[2]} del O E C E) " }
            t = t.replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1")
                .replace(Regex("^#{1,4}\\s*", RegexOption.MULTILINE), "")
                .replace(Regex("\\*\\*|__|`"), "")
                .replace(Regex("^\\s*[-*•]\\s+", RegexOption.MULTILINE), "")
                .replace(Regex("\\bart\\.\\s*", RegexOption.IGNORE_CASE), "artículo ")
                .replace("D.S.", "Decreto Supremo")
                .replace(Regex("\\bN\\.?\\s*[°º]"), "número")
                .replace(Regex("\\bUIT\\b"), "U I T")
                .replace(Regex("\\bOECE\\b"), "O E C E")
                .replace(Regex("\\bDEC\\b"), "D E C")
            return t.replace(Regex("\\n{2,}"), ". ").replace("\n", " ").replace(Regex("\\s{2,}"), " ").trim()
        }

        private fun trozos(t: String): List<String> {
            val partes = Regex("(?:[^.!?;:]|[.:](?=\\d))+[.!?;:]?").findAll(t).map { it.value }.toList().ifEmpty { listOf(t) }
            val out = ArrayList<String>()
            val buf = StringBuilder()
            for (p in partes) {
                if (buf.length + p.length > 380 && buf.isNotEmpty()) { out.add(buf.toString().trim()); buf.clear() }
                buf.append(p)
            }
            if (buf.isNotBlank()) out.add(buf.toString().trim())
            return out.filter { it.isNotBlank() }
        }
    }
}
