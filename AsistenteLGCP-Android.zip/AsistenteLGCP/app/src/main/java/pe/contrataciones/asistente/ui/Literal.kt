package pe.contrataciones.asistente.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import pe.contrataciones.asistente.data.Ficha
import pe.contrataciones.asistente.data.Frag
import pe.contrataciones.asistente.data.TextUtil
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.min

private val AMBAR_L = Color(0xFF9A5B13)
private val RESALTE = Color(0x55F2C14E)
private val SERIF_L = FontFamily.Serif

// ============================ Utilidades ============================

private val PALABRA = Regex("[\\p{L}\\d]+")

/** Resalta en negrita y fondo las palabras del texto que coinciden con la búsqueda. */
fun resaltarTexto(texto: String, consulta: Set<String>, base: SpanStyle = SpanStyle()): AnnotatedString = buildAnnotatedString {
    if (consulta.isEmpty()) { withStyle(base) { append(texto) }; return@buildAnnotatedString }
    var pos = 0
    for (m in PALABRA.findAll(texto)) {
        if (m.range.first > pos) withStyle(base) { append(texto.substring(pos, m.range.first)) }
        val tok = TextUtil.norm(m.value)
        val hit = tok.length > 1 && TextUtil.stem(tok) in consulta
        if (hit) withStyle(base.merge(SpanStyle(fontWeight = FontWeight.Bold, background = RESALTE))) { append(m.value) }
        else withStyle(base) { append(m.value) }
        pos = m.range.last + 1
    }
    if (pos < texto.length) withStyle(base) { append(texto.substring(pos)) }
}

/** La oración del fragmento con más coincidencias (para resultados largos). */
private fun oracionClave(texto: String, consulta: Set<String>): String {
    val oraciones = texto.split(Regex("(?<=[.;:])\\s+")).filter { it.isNotBlank() }
    if (oraciones.size <= 1 || consulta.isEmpty()) return texto
    return oraciones.maxByOrNull { o -> TextUtil.tokens(o).count { it in consulta } } ?: texto
}

fun compartirTexto(ctx: Context, texto: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, texto) }
    try { ctx.startActivity(Intent.createChooser(i, "Compartir por…")) } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No hay aplicaciones para compartir.", Toast.LENGTH_SHORT).show()
    }
}

private fun soles(v: Double): String = NumberFormat.getNumberInstance(Locale("es", "PE")).apply {
    minimumFractionDigits = 2; maximumFractionDigits = 2
}.format(v).let { "S/ $it" }

private fun numero(s: String): Double? = s.replace(" ", "").replace(",", "").toDoubleOrNull()

// ============================ BUSCAR ============================

private val BUSQUEDAS_RAPIDAS = listOf(
    "prestación adicional de obra", "ampliación de plazo", "penalidad por mora", "valorización", "recepción de obra",
    "liquidación de obra", "resolución del contrato", "garantía de fiel cumplimiento", "194.2", "120.1"
)

@Composable
fun BuscarScreen(vm: AppVM) {
    val ctx = LocalContext.current
    var q by rememberSaveable { mutableStateOf("") }
    var filtro by rememberSaveable { mutableStateOf("todas") }
    var soloFavs by rememberSaveable { mutableStateOf(false) }
    var resultados by remember { mutableStateOf<List<Frag>>(emptyList()) }
    var buscando by remember { mutableStateOf(false) }
    val consulta = remember(q) { TextUtil.tokens(q).toSet() }
    val dictado = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { if (it.isNotBlank()) q = it }
    }
    LaunchedEffect(q, filtro, soloFavs, vm.favoritos) {
        if (soloFavs) {
            resultados = vm.favoritos.mapNotNull { vm.repo.frag(it) }.filter { filtro == "todas" || it.norma == filtro }
                .sortedWith(compareBy<Frag>({ it.norma != "ley" }, { it.id }))
            return@LaunchedEffect
        }
        if (q.isBlank()) { resultados = emptyList(); return@LaunchedEffect }
        buscando = true
        delay(220)
        resultados = withContext(Dispatchers.Default) { vm.repo.searchFrags(q, 40, if (filtro == "todas") null else filtro) }
        buscando = false
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = q, onValueChange = { q = it; soloFavs = false }, singleLine = true, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    placeholder = { Text("Palabras o numeral (ej. 194.2 d)") },
                    trailingIcon = { if (q.isNotEmpty()) TextButton(onClick = { q = "" }) { Text("✕") } }
                )
                Spacer(Modifier.width(6.dp))
                FilledTonalIconButton(onClick = {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "¿Qué desea buscar?")
                    }
                    try { dictado.launch(i) } catch (e: ActivityNotFoundException) {
                        Toast.makeText(ctx, "Este teléfono no tiene reconocimiento de voz instalado.", Toast.LENGTH_LONG).show()
                    }
                }) { Text("🎤", fontSize = 18.sp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("todas" to "Todas", "ley" to "Ley", "reglamento" to "Reglamento").forEach { (id, t) ->
                    FilterChip(selected = filtro == id, onClick = { filtro = id }, label = { Text(t) })
                }
                FilterChip(selected = soloFavs, onClick = { soloFavs = !soloFavs }, label = { Text("★ ${vm.favoritos.size}") })
            }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp, 0.dp, 12.dp, 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!soloFavs && q.isBlank()) {
                item { InicioBuscar(vm) { q = it } }
            } else {
                if (!soloFavs && vm.hayClave() && q.isNotBlank()) item {
                    OutlinedButton(onClick = { vm.preguntarSobre(q) }, modifier = Modifier.fillMaxWidth()) {
                        Text("✨ Explicar con IA: «${q.take(40)}»", fontSize = 13.sp)
                    }
                }
                item {
                    Text(
                        when {
                            buscando -> "Buscando…"
                            soloFavs && resultados.isEmpty() -> "Aún no tiene favoritos. Toque ☆ en un resultado para guardarlo."
                            soloFavs -> "${resultados.size} favoritos"
                            resultados.isEmpty() -> "Sin coincidencias en el texto. Pruebe otras palabras o el número del artículo."
                            else -> "${resultados.size} numerales y literales · texto oficial, sin interpretación"
                        }, fontSize = 12.sp, color = Color.Gray
                    )
                }
                items(resultados, key = { it.id }) { f -> TarjetaFrag(vm, f, consulta) }
            }
        }
    }
}

@Composable
private fun InicioBuscar(vm: AppVM, buscar: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Busque en la Ley 32069 y su Reglamento", fontFamily = SERIF_L, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Los resultados son el texto oficial de cada numeral o literal, con la cita exacta. " +
                    "No se genera ni interpreta nada: funciona sin internet.", fontSize = 14.sp, color = Color.Gray)
                Text("Ley al ${vm.repo.normaById("ley").vigenteAl} · Reglamento al ${vm.repo.normaById("reglamento").vigenteAl}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
        }
        Text("Búsquedas frecuentes", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        FlowRowSimple(BUSQUEDAS_RAPIDAS) { buscar(it) }
        Text("Trámites paso a paso", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        vm.repo.fichas.take(3).forEach { TarjetaFichaResumen(it) { vm.verFicha = it } }
        TextButton(onClick = { vm.tab = Tab.FICHAS }) { Text("Ver todos los trámites →") }
    }
}

@Composable
private fun FlowRowSimple(textos: List<String>, onClick: (String) -> Unit) {
    // Filas simples de 2 en 2 (evita depender de APIs experimentales de FlowRow).
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        textos.chunked(2).forEach { fila ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                fila.forEach { t ->
                    Surface(shape = RoundedCornerShape(50), border = BorderStroke(1.dp, Color(0x33000000)),
                        modifier = Modifier.clickable { onClick(t) }) {
                        Text(t, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TarjetaFrag(vm: AppVM, f: Frag, consulta: Set<String>) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var completo by remember(f.id) { mutableStateOf(f.texto.length <= 520) }
    val ops = remember(f.norma, f.art, vm.version) { vm.repo.opinionesDe(f.norma, f.art) }
    val fav = vm.esFavorito(f)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { vm.abrirFrag(f) }) {
                    Text(f.label, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (f.ti.isNotBlank() && f.art.isNotBlank()) Text(f.ti, fontSize = 12.sp, color = Color.Gray, maxLines = 2)
                }
                TextButton(onClick = { vm.alternarFavorito(f) }) { Text(if (fav) "★" else "☆", fontSize = 20.sp, color = AMBAR_L) }
            }
            if (f.lit.isNotBlank() && f.intro.isNotBlank())
                Text(f.intro, fontSize = 12.sp, color = Color.Gray, maxLines = 2, fontStyle = FontStyle.Italic)
            val cuerpo = (if (f.lit.isNotBlank()) "${f.lit}) " else "") + if (completo) f.texto else "… " + oracionClave(f.texto, consulta) + " …"
            SelectionContainer {
                Text(resaltarTexto(cuerpo, consulta), fontFamily = SERIF_L, fontSize = 15.sp, lineHeight = 23.sp)
            }
            if (!completo) TextButton(onClick = { completo = true }, contentPadding = PaddingValues(0.dp)) { Text("Ver texto completo del numeral", fontSize = 13.sp) }
            if (f.nota.isNotBlank()) Surface(color = AMBAR_L.copy(alpha = 0.10f), shape = RoundedCornerShape(8.dp)) {
                Text("Modificación: " + f.nota, Modifier.padding(8.dp), fontSize = 12.sp, color = AMBAR_L)
            }
            if (ops.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ops.take(4)) { o -> Box(Modifier.clickable { vm.verOpinion = o }) { Pastilla("⚖️ ${o.numero.substringBefore("-OECE")}", AMBAR_L) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                AccionChica("Copiar") {
                    clip.setText(AnnotatedString(vm.repo.textoParaCopiar(f)))
                    Toast.makeText(ctx, "Copiado con la cita", Toast.LENGTH_SHORT).show()
                }
                AccionChica("Compartir") { compartirTexto(ctx, vm.repo.textoParaCopiar(f)) }
                AccionChica("Artículo") { vm.abrirFrag(f) }
                if (vm.hayClave()) AccionChica("✨ Explicar") { vm.explicar(f) }
            }
        }
    }
}

@Composable
private fun AccionChica(texto: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text(texto, fontSize = 13.sp) }
}

// ============================ TRÁMITES (fichas) ============================

@Composable
fun FichasScreen(vm: AppVM) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Cada paso muestra el plazo con las palabras exactas del Reglamento o la Ley. Toque la referencia para leer el numeral completo.",
                fontSize = 13.sp, color = Color.Gray)
        }
        items(vm.repo.fichas, key = { it.id }) { f -> TarjetaFichaResumen(f) { vm.verFicha = f } }
    }
}

@Composable
private fun TarjetaFichaResumen(f: Ficha, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(f.titulo, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                if (f.sub.isNotBlank()) Text(f.sub, fontSize = 12.sp, color = Color.Gray)
                Text(f.base + " · ${f.pasos.size} pasos" + if (f.calculadora.isNotBlank()) " · calculadora" else "",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
            Text("›", fontSize = 24.sp, color = Color.Gray)
        }
    }
}

private fun textoFicha(vm: AppVM, f: Ficha): String = buildString {
    append(f.titulo.uppercase()).append("\n").append(f.base).append("\n\n")
    f.pasos.forEachIndexed { i, p ->
        append("${i + 1}. ${p.titulo} (${p.actor})")
        if (p.plazo.isNotBlank()) append(" — «${p.plazo}»")
        append(" [${p.ref}]\n")
    }
    if (f.limites.isNotEmpty()) {
        append("\nLímites:\n")
        f.limites.forEach { append("• ${it.etiqueta}: ${it.valor.toInt()} % [${it.ref}]\n") }
    }
    append("\nTexto oficial: Ley N.° 32069 y su Reglamento (D.S. N.° 009-2025-EF).")
}

@Composable
fun FichaScreen(vm: AppVM, f: Ficha) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    Dialog(onDismissRequest = { vm.verFicha = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.verFicha = null }) { Text("← Volver") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { clip.setText(AnnotatedString(textoFicha(vm, f))); Toast.makeText(ctx, "Ficha copiada", Toast.LENGTH_SHORT).show() }) { Text("Copiar") }
                    TextButton(onClick = { compartirTexto(ctx, textoFicha(vm, f)) }) { Text("Compartir") }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TRÁMITE", fontSize = 11.sp, color = Color.Gray)
                    Text(f.titulo, fontFamily = SERIF_L, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    if (f.sub.isNotBlank()) Text(f.sub, fontSize = 13.sp, color = Color.Gray)
                    Text(f.base, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    when (f.calculadora) {
                        "penalidad" -> CalcPenalidad(vm)
                        "apercibimiento" -> CalcApercibimiento(vm)
                        "subsanacion" -> CalcSubsanacion(vm)
                    }
                    Text("Línea de tiempo", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                    f.pasos.forEachIndexed { i, p -> PasoLinea(vm, i + 1, p, i == f.pasos.lastIndex) }
                    if (f.limites.isNotEmpty()) Limites(vm, f)
                    val ops = f.opiniones.mapNotNull { vm.repo.opinion(it) }
                    if (ops.isNotEmpty()) {
                        Text("Opiniones del OECE relacionadas", fontWeight = FontWeight.SemiBold)
                        ops.forEach { o ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth().clickable { vm.verOpinion = o }) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("Opinión ${o.numero}", color = AMBAR_L, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(o.asunto, fontSize = 13.sp, maxLines = 3)
                                }
                            }
                        }
                    }
                    Text("Guía de lectura basada en el texto oficial; no reemplaza la revisión de las bases, el contrato ni la normativa vigente a la fecha del hecho.",
                        fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun PasoLinea(vm: AppVM, n: Int, p: pe.contrataciones.asistente.data.Paso, ultimo: Boolean) {
    val primario = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(Modifier.width(34.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(26.dp).background(primario, CircleShape), contentAlignment = Alignment.Center) {
                Text("$n", color = MaterialTheme.colorScheme.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            if (!ultimo) Box(Modifier.width(2.dp).weight(1f).background(primario.copy(alpha = 0.3f)))
        }
        Column(Modifier.weight(1f).padding(start = 8.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Pastilla(p.momento, AMBAR_L)
                Spacer(Modifier.width(6.dp))
                Text(p.actor, fontSize = 12.sp, color = Color.Gray)
            }
            Text(p.titulo, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (p.plazo.isNotBlank()) Surface(color = RESALTE, shape = RoundedCornerShape(6.dp)) {
                Text("«${p.plazo}»", Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontFamily = SERIF_L, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            if (p.cita.isNotBlank()) Text("“${p.cita}…”", fontFamily = SERIF_L, fontStyle = FontStyle.Italic, fontSize = 13.sp, color = Color.DarkGray)
            if (p.nota.isNotBlank()) Text(p.nota, fontSize = 12.sp, color = AMBAR_L)
            Text(p.ref + " ›", color = primario, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                modifier = Modifier.clickable { vm.abrirFragId(p.frag) })
        }
    }
}

@Composable
private fun Limites(vm: AppVM, f: Ficha) {
    Text("Límites", fontWeight = FontWeight.SemiBold)
    val max = f.limites.maxOf { it.valor }.coerceAtLeast(1.0)
    f.limites.forEach { l ->
        Column(Modifier.fillMaxWidth().clickable { vm.abrirFragId(l.frag) }.padding(vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(l.etiqueta, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("${l.valor.toInt()} %", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x14000000), RoundedCornerShape(4.dp))) {
                Box(Modifier.fillMaxWidth((l.valor / max).toFloat()).fillMaxHeight().background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp)))
            }
            Text("“${l.cita}” · ${l.ref} ›", fontSize = 12.sp, color = Color.Gray, fontStyle = FontStyle.Italic)
        }
    }
}

// ============================ Calculadoras ============================

@Composable
private fun Calculadora(titulo: String, ref: String, vm: AppVM, contenido: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🧮 $titulo", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(ref, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable { vm.repo.fragByLabel(ref)?.let { vm.abrirFrag(it) } })
            }
            contenido()
        }
    }
}

@Composable
private fun CampoNumero(valor: String, etiqueta: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(value = valor, onValueChange = { onChange(it.filter { c -> c.isDigit() || c == '.' || c == ',' }) },
        label = { Text(etiqueta, fontSize = 12.sp) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

@Composable
private fun Resultado(etiqueta: String, valor: String, fuerte: Boolean = false) {
    Row(Modifier.fillMaxWidth()) {
        Text(etiqueta, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(valor, fontSize = if (fuerte) 16.sp else 14.sp, fontWeight = if (fuerte) FontWeight.Bold else FontWeight.Medium)
    }
}

/** Fórmula del numeral 120.1 del Reglamento: Penalidad diaria = 0.10 x monto / (F x plazo). */
@Composable
private fun CalcPenalidad(vm: AppVM) {
    var monto by rememberSaveable { mutableStateOf("") }
    var plazo by rememberSaveable { mutableStateOf("") }
    var atraso by rememberSaveable { mutableStateOf("") }
    var tipo by rememberSaveable { mutableStateOf("obra") }
    Calculadora("Penalidad por mora", "Reglamento, art. 120.1", vm) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("bys" to "Bienes y servicios", "obra" to "Obra", "cons" to "Consultoría de obra").forEach { (id, t) ->
                FilterChip(selected = tipo == id, onClick = { tipo = id }, label = { Text(t, fontSize = 11.sp) })
            }
        }
        CampoNumero(monto, "Monto vigente (S/)", Modifier.fillMaxWidth()) { monto = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CampoNumero(plazo, "Plazo vigente (días)", Modifier.weight(1f)) { plazo = it }
            CampoNumero(atraso, "Días de atraso", Modifier.weight(1f)) { atraso = it }
        }
        val m = numero(monto); val p = numero(plazo); val a = numero(atraso) ?: 0.0
        if (m != null && p != null && m > 0 && p > 0) {
            val f = when (tipo) {
                "bys" -> 0.40
                "cons" -> if (p <= 60) 0.40 else 0.25
                else -> if (p <= 60) 0.40 else if (p <= 120) 0.25 else 0.15
            }
            val diaria = 0.10 * m / (f * p)
            val tope = 0.10 * m
            val total = min(diaria * a, tope)
            HorizontalDivider()
            Resultado("Factor F", "%.2f".format(Locale.US, f))
            Resultado("Penalidad diaria", soles(diaria))
            if (a > 0) Resultado("Penalidad por ${a.toInt()} días", soles(total), true)
            Resultado("Tope 10 % del monto vigente", soles(tope))
            Resultado("Días de atraso que agotan el tope", "${ceil(tope / diaria).toInt()} días")
            if (a > 0 && diaria * a >= tope) Text("Se alcanzó el monto máximo de penalidad: la entidad puede resolver el contrato sin requerimiento previo (Reglamento, art. 122.2).",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            Text("El tope del 10 % es para la suma de penalidad por mora y otras penalidades (Reglamento, art. 119.2). " +
                "Para obras, F depende del plazo: hasta 60 días 0.40; de 61 a 120 días 0.25; más de 120 días 0.15.", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

/** Literal a) del numeral 122.1 del Reglamento. */
@Composable
private fun CalcApercibimiento(vm: AppVM) {
    var plazo by rememberSaveable { mutableStateOf("") }
    var obra by rememberSaveable { mutableStateOf(false) }
    Calculadora("Plazo para cumplir bajo apercibimiento", "Reglamento, art. 122.1 a)", vm) {
        CampoNumero(plazo, "Plazo del contrato, ítem o entregable (días)", Modifier.fillMaxWidth()) { plazo = it }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = obra, onCheckedChange = { obra = it })
            Text("Retraso en el componente de ejecución de obra (solo construcción o diseño y construcción)", fontSize = 13.sp)
        }
        val p = numero(plazo)
        if (p != null && p > 0) {
            HorizontalDivider()
            when {
                obra && p > 60 -> Resultado("Plazo a otorgar", "15 días", true)
                p < 30 -> Resultado("Plazo a otorgar", "3 días", true)
                else -> {
                    Resultado("Mínimo (10 %)", "${ceil(p * 0.10).toInt()} días", true)
                    Resultado("Máximo (15 %)", "${ceil(p * 0.15).toInt()} días")
                }
            }
            Text("Si el porcentaje da decimales, el redondeo es a favor del contratista (un día completo adicional). " +
                "Menos de treinta días: tres días. Obra con plazo de ejecución mayor a 60 días: quince días. Verifique el texto del literal.",
                fontSize = 12.sp, color = Color.Gray)
        }
    }
}

/** Numeral 212.6 del Reglamento: un décimo del plazo de ejecución vigente o cuarenta días, el menor. */
@Composable
private fun CalcSubsanacion(vm: AppVM) {
    var plazo by rememberSaveable { mutableStateOf("") }
    Calculadora("Plazo para subsanar observaciones", "Reglamento, art. 212.6", vm) {
        CampoNumero(plazo, "Plazo de ejecución vigente de la obra (días)", Modifier.fillMaxWidth()) { plazo = it }
        val p = numero(plazo)
        if (p != null && p > 0) {
            val decimo = p / 10.0
            HorizontalDivider()
            Resultado("Un décimo del plazo", "%.1f días".format(Locale.US, decimo))
            Resultado("Plazo para subsanar", if (decimo < 40) "%.1f días".format(Locale.US, decimo) else "40 días", true)
            Text("Se computa desde el día siguiente de la emisión del pliego de observaciones. El numeral no regula el redondeo de decimales.",
                fontSize = 12.sp, color = Color.Gray)
        }
    }
}
