package pe.contrataciones.asistente.data

/** Un artículo, disposición, anexo o fragmento de la Ley o del Reglamento. */
data class Item(
    val id: String,
    val norma: String,   // "ley" | "reglamento"
    val t: String,       // "art" | "disp" | "anexo" | "texto"
    val n: String,       // número del artículo u ordinal de la disposición
    val ti: String,      // título
    val x: String,       // texto
    val u: String,       // ubicación (Título · Capítulo)
    val tt: String,      // "Título I"
    val tn: String,      // nombre del título
    val ct: String,      // "Capítulo II"
    val cn: String       // nombre del capítulo
)

data class Norma(
    val id: String,
    val corto: String,
    val nombre: String,
    val vigenteAl: String,
    val fuente: String,
    val items: List<Item>
)

data class Opinion(
    val numero: String,
    val fecha: String,
    val fechaTexto: String,
    val solicitante: String,
    val asunto: String,
    val normativa: String,
    val criterio: String,
    val articulos: List<String>,
    val url: String,
    val verificado: Boolean,
    val agregadaPorActualizacion: Boolean = false
)

data class Novedad(
    val tipo: String,      // "Opinión" | "Norma" | "Resolución"
    val numero: String,
    val fecha: String,
    val titulo: String,
    val resumen: String,
    val url: String,
    val accion: String,
    val detectado: String
)

/** Grupo del índice (un Título, o Disposiciones / Anexos / Otros). */
data class Grupo(val key: String, val cabecera: String, val nombre: String, val items: List<Item>)

/** Numeral o literal de un artículo: la unidad que muestra la búsqueda literal. */
data class Frag(
    val id: Int,
    val norma: String,   // "ley" | "reglamento"
    val art: String,     // "194" ("" en disposiciones)
    val num: String,     // "194.2"
    val lit: String,     // "d"
    val label: String,   // "Reglamento, art. 194.2 d)"
    val texto: String,
    val intro: String,   // encabezado del numeral, si el fragmento es un literal
    val nota: String,    // nota de modificación (SPIJ)
    val item: String,    // id del Item (artículo completo)
    val ti: String,      // título del artículo
    val tt: String,
    val ct: String
)

data class Paso(
    val momento: String, val titulo: String, val actor: String, val plazo: String,
    val ref: String, val cita: String, val nota: String, val frag: Int
)

data class Limite(val etiqueta: String, val valor: Double, val ref: String, val cita: String, val frag: Int)

/** Ficha de procedimiento: cada paso remite a un fragmento cuyo texto contiene literalmente el plazo. */
data class Ficha(
    val id: String, val titulo: String, val sub: String, val base: String,
    val pasos: List<Paso>, val limites: List<Limite>, val calculadora: String, val opiniones: List<String>
)
