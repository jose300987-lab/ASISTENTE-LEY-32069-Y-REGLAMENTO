package pe.contrataciones.asistente.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

/**
 * Muestra la respuesta del asistente: Markdown sencillo (títulos, negritas, viñetas, citas)
 * con las citas normativas pulsables, y los gráficos ```linea / ```flujo / ```barras.
 */
@Composable
fun RichText(md: String, onCite: (String) -> Unit) {
    val bloques = remember(md) { dividir(md) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (b in bloques) {
            when (b) {
                is Bloque.Texto -> TextoMd(b.texto, onCite)
                is Bloque.Grafico -> Grafico(b.tipo, b.json, onCite)
            }
        }
    }
}

private sealed class Bloque {
    data class Texto(val texto: String) : Bloque()
    data class Grafico(val tipo: String, val json: String) : Bloque()
}

private fun dividir(src: String): List<Bloque> {
    val out = ArrayList<Bloque>()
    val re = Regex("```[ \\t]*([a-zA-Z]*)[^\\n]*\\n([\\s\\S]*?)(```|$)")
    var last = 0
    for (m in re.findAll(src)) {
        if (m.range.first > last) out.add(Bloque.Texto(src.substring(last, m.range.first)))
        out.add(Bloque.Grafico(m.groupValues[1].lowercase(), m.groupValues[2]))
        last = m.range.last + 1
    }
    if (last < src.length) out.add(Bloque.Texto(src.substring(last)))
    return out
}

@Composable
private fun TextoMd(src: String, onCite: (String) -> Unit) {
    val colorCita = MaterialTheme.colorScheme.primary
    val colorOp = Color(0xFF9A5B13)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (raw in src.replace("\r", "").split("\n")) {
            val l = raw.trimEnd()
            if (l.isBlank()) continue
            val h = Regex("^\\s{0,3}#{1,4}\\s+(.*)$").find(l)
            val bullet = Regex("^\\s*[-*•]\\s+(.*)$").find(l)
            val num = Regex("^\\s*(\\d+)[.)]\\s+(.*)$").find(l)
            val quote = Regex("^\\s*>\\s?(.*)$").find(l)
            when {
                h != null -> Text(enLinea(h.groupValues[1], colorCita, colorOp, onCite),
                    fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, fontSize = 15.sp)
                bullet != null -> Row {
                    Text("•  ", color = MaterialTheme.colorScheme.primary)
                    Text(enLinea(bullet.groupValues[1], colorCita, colorOp, onCite), fontSize = 15.sp)
                }
                num != null -> Row {
                    Text("${num.groupValues[1]}. ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Text(enLinea(num.groupValues[2], colorCita, colorOp, onCite), fontSize = 15.sp)
                }
                quote != null -> Box(
                    Modifier.fillMaxWidth().background(Color(0x1A9A5B13), RoundedCornerShape(6.dp)).padding(8.dp)
                ) { Text(enLinea(quote.groupValues[1], colorCita, colorOp, onCite), fontSize = 15.sp) }
                Regex("^\\s*([-*_])\\1{2,}\\s*$").matches(l) -> Spacer(Modifier.height(4.dp))
                else -> Text(enLinea(l, colorCita, colorOp, onCite), fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
    }
}

/** Negritas, cursivas y citas [Ley, art. N] / [Opinión …] pulsables. */
private fun enLinea(s: String, cCita: Color, cOp: Color, onCite: (String) -> Unit): AnnotatedString = buildAnnotatedString {
    val re = Regex("\\*\\*([^*]+)\\*\\*|\\[([^\\[\\]]{3,120})\\](?!\\()|\\[([^\\]]+)\\]\\((https?://[^)\\s]+)\\)|(?<![*\\w])\\*([^*\\n]+)\\*(?![*\\w])")
    var last = 0
    for (m in re.findAll(s)) {
        append(s.substring(last, m.range.first))
        when {
            m.groupValues[1].isNotEmpty() -> withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(m.groupValues[1]) }
            m.groupValues[2].isNotEmpty() -> {
                val c = m.groupValues[2]
                val esCita = Regex("^(ley|reglamento|opini)", RegexOption.IGNORE_CASE).containsMatchIn(c.trim())
                if (esCita) {
                    val color = if (c.trim().lowercase().startsWith("opini")) cOp else cCita
                    withLink(LinkAnnotation.Clickable(
                        tag = c,
                        styles = TextLinkStyles(SpanStyle(color = color, fontWeight = FontWeight.Medium, background = color.copy(alpha = 0.10f))),
                        linkInteractionListener = { onCite(c) }
                    )) { append(" $c ") }
                } else append(m.value)
            }
            m.groupValues[3].isNotEmpty() -> withLink(LinkAnnotation.Url(m.groupValues[4],
                TextLinkStyles(SpanStyle(color = cCita)))) { append(m.groupValues[3]) }
            m.groupValues[5].isNotEmpty() -> withStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) { append(m.groupValues[5]) }
        }
        last = m.range.last + 1
    }
    append(s.substring(last))
}

// ---------------- Gráficos ----------------

@Composable
private fun Grafico(tipo: String, cuerpo: String, onCite: (String) -> Unit) {
    if (tipo !in listOf("linea", "flujo", "barras")) {
        Text(cuerpo, fontSize = 12.sp, modifier = Modifier.background(Color(0x11000000)).padding(8.dp)); return
    }
    val d = runCatching { JSONObject(cuerpo.trim()) }.getOrNull()
    val marco = Modifier.fillMaxWidth()
        .border(1.dp, Color(0x22000000), RoundedCornerShape(12.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
        .padding(12.dp)
    if (d == null) { Text("No se pudo dibujar el gráfico.", modifier = marco, fontSize = 13.sp); return }
    val verde = MaterialTheme.colorScheme.primary
    val ambar = Color(0xFF9A5B13)
    Column(marco, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        d.optString("titulo").takeIf { it.isNotBlank() }?.let { Text(it, fontWeight = FontWeight.SemiBold, color = verde) }
        when (tipo) {
            "linea" -> {
                val hs = d.optJSONArray("hitos")
                for (i in 0 until minOf(hs?.length() ?: 0, 12)) {
                    val h = hs!!.getJSONObject(i)
                    Row {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(18.dp)) {
                            Box(Modifier.size(12.dp).border(3.dp, verde, CircleShape))
                            if (i < hs.length() - 1) Box(Modifier.width(2.dp).height(54.dp).background(verde))
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.optString("momento").uppercase(), color = ambar, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(h.optString("titulo"), fontWeight = FontWeight.SemiBold)
                            h.optString("detalle").takeIf { it.isNotBlank() }?.let { Text(it, fontSize = 13.sp, color = Color.Gray) }
                            Etiquetas(h.optString("responsable"), "", h.optString("cita"), onCite)
                        }
                    }
                }
            }
            "flujo" -> {
                val ps = d.optJSONArray("pasos")
                val n = minOf(ps?.length() ?: 0, 12)
                for (i in 0 until n) {
                    val p = ps!!.getJSONObject(i)
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0x22000000), RoundedCornerShape(10.dp)).padding(10.dp)) {
                        Box(Modifier.size(26.dp).background(verde, CircleShape), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Etiquetas(p.optString("actor"), p.optString("plazo"), "", onCite)
                            Text(p.optString("accion"))
                            p.optString("alternativa").takeIf { it.isNotBlank() }?.let { Text("↳ $it", fontSize = 13.sp, color = Color(0xFFA33B2B)) }
                            Etiquetas("", "", p.optString("cita"), onCite)
                        }
                    }
                    if (i < n - 1) Text("↓", color = verde, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
            "barras" -> {
                val its = d.optJSONArray("items")
                val unidad = d.optString("unidad")
                val vals = (0 until minOf(its?.length() ?: 0, 12)).map { its!!.getJSONObject(it) }.filter { it.has("valor") }
                val max = (vals.maxOfOrNull { it.optDouble("valor", 0.0) } ?: 1.0).coerceAtLeast(1e-9)
                for (x in vals) {
                    val v = x.optDouble("valor", 0.0)
                    Column {
                        Text(x.optString("etiqueta"), fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                Box(Modifier.fillMaxWidth((v / max).toFloat().coerceIn(0.02f, 1f)).height(16.dp).background(verde, RoundedCornerShape(4.dp)))
                            }
                            Spacer(Modifier.width(8.dp))
                            val vs = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
                            Text(vs + if (unidad == "%") "%" else if (unidad.isNotBlank()) " $unidad" else "", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                        Etiquetas("", "", x.optString("cita"), onCite)
                    }
                }
            }
        }
    }
}

@Composable
private fun Etiquetas(actor: String, plazo: String, cita: String, onCite: (String) -> Unit) {
    if (actor.isBlank() && plazo.isBlank() && cita.isBlank()) return
    val prim = MaterialTheme.colorScheme.primary
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (actor.isNotBlank()) Pastilla(actor, prim)
        if (plazo.isNotBlank()) Pastilla("⏱ $plazo", Color(0xFF9A5B13))
        if (cita.isNotBlank()) {
            val c = cita.replace("[", "").replace("]", "")
            Text(buildAnnotatedString {
                withLink(LinkAnnotation.Clickable(c, TextLinkStyles(SpanStyle(color = prim,
                    background = prim.copy(alpha = 0.10f))), { onCite(c) })) { append(" $c ") }
            }, fontSize = 12.sp)
        }
    }
}

@Composable
fun Pastilla(texto: String, color: Color) {
    Text(texto, color = color, fontSize = 12.sp,
        modifier = Modifier.background(color.copy(alpha = 0.12f), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 2.dp))
}
