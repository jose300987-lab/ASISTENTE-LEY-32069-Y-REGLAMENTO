package pe.contrataciones.asistente.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Textos normativos (incluidos en la app), opiniones del OECE (incluidas + las que agregue
 * la búsqueda de actualizaciones) y novedades. Todo se lee una vez al iniciar.
 */
class Repo(private val ctx: Context) {

    lateinit var normas: List<Norma>; private set
    lateinit var items: List<Item>; private set
    var opiniones: List<Opinion> = emptyList(); private set
    var novedades: List<Novedad> = emptyList(); private set
    private lateinit var idxN: Bm25<Item>
    private lateinit var idxO: Bm25<Opinion>
    lateinit var frags: List<Frag>; private set
    lateinit var fichas: List<Ficha>; private set
    private lateinit var idxF: Bm25<Frag>
    private val itemById = HashMap<String, Item>()
    private val fragsByItem = HashMap<String, MutableList<Frag>>()
    private val fragByLabel = HashMap<String, Frag>()

    fun load() {
        normas = listOf(loadNorma("ley.json"), loadNorma("reglamento.json"))
        items = normas.flatMap { it.items }
        idxN = Bm25(items) {
            val t = TextUtil.tokens(it.ti)
            t + t + t + TextUtil.tokens(it.u) + TextUtil.tokens(it.x)
        }
        items.forEach { itemById[it.id] = it }
        frags = loadFrags()
        frags.forEach { f ->
            fragsByItem.getOrPut(f.item) { mutableListOf() }.add(f)
            fragByLabel.putIfAbsent(TextUtil.norm(f.label).replace(" ", ""), f)
        }
        idxF = Bm25(frags) {
            val t = TextUtil.tokens(it.ti)
            t + t + TextUtil.tokens(it.intro) + TextUtil.tokens(it.texto) + TextUtil.tokens(it.texto)
        }
        fichas = loadFichas()
        reloadDynamic()
    }

    private fun loadFrags(): List<Frag> {
        val arr = JSONArray(readAsset("fragmentos.json"))
        return (0 until arr.length()).map { i ->
            val j = arr.getJSONObject(i)
            Frag(j.getInt("id"), j.optString("norma"), j.optString("art"), j.optString("num"), j.optString("lit"),
                j.optString("label"), j.optString("texto"), j.optString("intro"), j.optString("nota"),
                j.optString("item"), j.optString("ti"), j.optString("tt"), j.optString("ct"))
        }
    }

    private fun loadFichas(): List<Ficha> {
        val arr = JSONArray(readAsset("fichas.json"))
        return (0 until arr.length()).map { i ->
            val j = arr.getJSONObject(i)
            val ps = j.getJSONArray("pasos")
            val ls = j.optJSONArray("limites") ?: JSONArray()
            val os = j.optJSONArray("opiniones") ?: JSONArray()
            Ficha(
                j.getString("id"), j.getString("titulo"), j.optString("sub"), j.optString("base"),
                (0 until ps.length()).map { k ->
                    val p = ps.getJSONObject(k)
                    Paso(p.optString("momento"), p.optString("titulo"), p.optString("actor"), p.optString("plazo"),
                        p.optString("ref"), p.optString("cita"), p.optString("nota"), p.optInt("frag", -1))
                },
                (0 until ls.length()).map { k ->
                    val p = ls.getJSONObject(k)
                    Limite(p.optString("etiqueta"), p.optDouble("valor"), p.optString("ref"), p.optString("cita"), p.optInt("frag", -1))
                },
                j.optString("calculadora"),
                (0 until os.length()).map { os.optString(it) }
            )
        }
    }

    // ---------------- Carga ----------------
    private fun readAsset(name: String) =
        ctx.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun loadNorma(file: String): Norma {
        val o = JSONObject(readAsset(file))
        val id = o.getString("id")
        val arr = o.getJSONArray("items")
        val list = ArrayList<Item>(arr.length())
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            list.add(
                Item(
                    "$id:$i", id, j.optString("t"), j.optString("n"), j.optString("ti"), j.optString("x"),
                    j.optString("u"), j.optString("tt"), j.optString("tn"), j.optString("ct"), j.optString("cn")
                )
            )
        }
        return Norma(id, o.getString("corto"), o.getString("nombre"), o.optString("vigenteAl"), o.optString("fuente"), list)
    }

    private fun parseOps(arr: JSONArray, extra: Boolean): List<Opinion> = (0 until arr.length()).map { i ->
        val j = arr.getJSONObject(i)
        val arts = j.optJSONArray("articulos")
        Opinion(
            numero = j.optString("numero").trim().uppercase(),
            fecha = j.optString("fecha"),
            fechaTexto = j.optString("fechaTexto"),
            solicitante = j.optString("solicitante"),
            asunto = j.optString("asunto"),
            normativa = j.optString("normativa", "Ley 32069 y su Reglamento"),
            criterio = j.optString("criterio"),
            articulos = if (arts == null) emptyList() else (0 until arts.length()).map { arts.optString(it) },
            url = j.optString("url"),
            verificado = j.optBoolean("verificado", false),
            agregadaPorActualizacion = extra
        )
    }.filter { it.numero.isNotBlank() }

    private fun opToJson(o: Opinion) = JSONObject()
        .put("numero", o.numero).put("fecha", o.fecha).put("fechaTexto", o.fechaTexto)
        .put("solicitante", o.solicitante).put("asunto", o.asunto).put("normativa", o.normativa)
        .put("criterio", o.criterio).put("articulos", JSONArray(o.articulos)).put("url", o.url)
        .put("verificado", o.verificado)

    private fun novToJson(n: Novedad) = JSONObject()
        .put("tipo", n.tipo).put("numero", n.numero).put("fecha", n.fecha).put("titulo", n.titulo)
        .put("resumen", n.resumen).put("url", n.url).put("accion", n.accion).put("detectado", n.detectado)

    private val extraOpsFile get() = File(ctx.filesDir, "opiniones_extra.json")
    private val novsFile get() = File(ctx.filesDir, "novedades.json")

    fun reloadDynamic() {
        val base = parseOps(JSONArray(readAsset("opiniones.json")), false)
        val extra = runCatching { parseOps(JSONArray(extraOpsFile.readText()), true) }.getOrDefault(emptyList())
        val map = LinkedHashMap<String, Opinion>()
        (base + extra).forEach { map[it.numero] = it }
        opiniones = map.values.sortedWith(compareByDescending<Opinion> { anio(it.numero) }.thenByDescending { it.numero })
        idxO = Bm25(opiniones) {
            val a = TextUtil.tokens(it.asunto)
            a + a + TextUtil.tokens(it.criterio) + TextUtil.tokens(it.articulos.joinToString(" ")) + TextUtil.tokens(it.numero)
        }
        novedades = runCatching {
            val arr = JSONArray(novsFile.readText())
            (0 until arr.length()).map { i ->
                val j = arr.getJSONObject(i)
                Novedad(
                    j.optString("tipo"), j.optString("numero"), j.optString("fecha"), j.optString("titulo"),
                    j.optString("resumen"), j.optString("url"), j.optString("accion"), j.optString("detectado")
                )
            }
        }.getOrDefault(emptyList()).sortedByDescending { it.detectado }
    }

    private fun anio(numero: String) = Regex("-(\\d{4})-").find(numero)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    /** Guarda lo encontrado por la búsqueda de actualizaciones. Devuelve cuántas cosas nuevas había. */
    @Synchronized
    fun addUpdates(newOps: List<Opinion>, newNovs: List<Novedad>): Int {
        val known = opiniones.map { it.numero }.toSet()
        val reallyNewOps = newOps.filter { it.numero !in known }
        val oldExtra = runCatching { JSONArray(extraOpsFile.readText()) }.getOrDefault(JSONArray())
        reallyNewOps.forEach { oldExtra.put(opToJson(it)) }
        extraOpsFile.writeText(oldExtra.toString())

        val knownNov = novedades.map { (it.tipo + it.numero).uppercase() }.toSet()
        val reallyNewNovs = newNovs.filter { (it.tipo + it.numero).uppercase() !in knownNov }
        val arr = runCatching { JSONArray(novsFile.readText()) }.getOrDefault(JSONArray())
        reallyNewNovs.forEach { arr.put(novToJson(it)) }
        novsFile.writeText(arr.toString())
        reloadDynamic()
        return reallyNewOps.size + reallyNewNovs.size
    }

    // ---------------- Consultas ----------------
    fun normaById(id: String) = normas.first { it.id == id }
    fun corto(it: Item) = normaById(it.norma).corto

    fun label(it: Item): String = when (it.t) {
        "art" -> "${corto(it)}, art. ${it.n}"
        "disp" -> "${corto(it)}, ${it.ti}"
        else -> "${corto(it)}, ${it.n}"
    }

    fun title(it: Item): String =
        if (it.t == "art") "Artículo ${it.n}" + (if (it.ti.isNotBlank()) ". ${it.ti}" else "") else it.ti.ifBlank { it.n }

    /** "Ley", "LGCP", "Reglamento"… → id de la norma. */
    fun normaKey(word: String?): String? {
        val w = TextUtil.norm(word ?: "").trim()
        if (w.isEmpty()) return null
        if (Regex("reglam|rlgcp|009-2025").containsMatchIn(w)) return "reglamento"
        if (w.startsWith("ley") || w.contains("lgcp") || w.contains("32069")) return "ley"
        return null
    }

    fun getArticle(normaId: String, num: String): Item? {
        val n = num.trim().uppercase().replace(Regex("[\\s-]"), "")
        return items.firstOrNull { it.norma == normaId && it.t == "art" && it.n.uppercase() == n }
    }

    fun findDisposicion(normaId: String?, text: String): Item? {
        val q = TextUtil.norm(text)
        val ords = listOf("primera", "segunda", "tercera", "cuarta", "quinta", "sexta", "septima", "setima", "octava", "novena",
            "decima", "undecima", "duodecima", "vigesima", "trigesima", "unica", "decimo", "vigesimo")
        val kind = listOf("final", "transitoria", "modificatoria", "derogatoria").firstOrNull { q.contains(it) }
        val words = Regex("[a-z]+").findAll(q).map { it.value }.toList()
        val ordWords = words.filter { w -> ords.any { w.startsWith(it) } }
        if (ordWords.isEmpty()) return null
        val key = ordWords.joinToString("")
        return items.firstOrNull { it.t == "disp" && (normaId == null || it.norma == normaId) &&
            (kind == null || TextUtil.norm(it.ti).contains(kind)) &&
            TextUtil.norm(it.ti).replace(Regex("[^a-z]"), "").startsWith(key) }
    }

    fun searchItems(q: String, k: Int = 8, normaId: String? = null): List<Item> =
        idxN.search(q, k, if (normaId == null) null else { it: Item -> it.norma == normaId })

    fun searchOps(q: String, k: Int = 5): List<Opinion> = idxO.search(q, k)

    fun opinion(code: String): Opinion? {
        val c = TextUtil.norm(code).uppercase()
        return opiniones.firstOrNull { it.numero.uppercase() == c }
            ?: opiniones.firstOrNull { it.numero.uppercase().contains(c.removePrefix("D").trimStart('0')) }
    }

    /** Artículos citados expresamente en la pregunta ("artículo 194 del Reglamento", "numeral 63.1 de la Ley"). */
    private fun explicitRefs(q: String): List<Pair<String?, String>> {
        val re = Regex("(art[íi]culos?|arts?\\.|numeral(?:es)?)\\s*(\\d{1,3})(?:\\.\\d+)*(?:[^.;?]{0,40}?\\b(ley|reglamento)\\b)?", RegexOption.IGNORE_CASE)
        return re.findAll(q).map { normaKey(it.groupValues[3]) to it.groupValues[2] }.toList()
    }

    /** Recuperación para una pregunta: artículos relevantes y opiniones relacionadas. */
    fun retrieve(q: String, withOps: Boolean, k: Int = 7): Pair<List<Item>, List<Opinion>> {
        val picked = LinkedHashMap<String, Item>()
        val hint = when {
            Regex("reglamento", RegexOption.IGNORE_CASE).containsMatchIn(q) -> "reglamento"
            Regex("\\bley\\b", RegexOption.IGNORE_CASE).containsMatchIn(q) -> "ley"
            else -> null
        }
        for ((norma, n) in explicitRefs(q)) {
            val ids = norma?.let { listOf(it) } ?: hint?.let { listOf(it) } ?: normas.map { it.id }
            ids.forEach { id -> getArticle(id, n)?.let { picked[it.id] = it } }
        }
        if (Regex("disposici[oó]n", RegexOption.IGNORE_CASE).containsMatchIn(q)) findDisposicion(hint, q)?.let { picked[it.id] = it }
        for (it in searchItems(q, k + 4)) {
            if (picked.size >= k + 3) break
            picked.putIfAbsent(it.id, it)
        }
        val arts = picked.values.toList()
        val ops = if (withOps && opiniones.isNotEmpty()) {
            val extra = arts.filter { it.t == "art" }.take(4).joinToString(" ") { "artículo ${it.n} ${it.n}" }
            searchOps("$q $extra", 5)
        } else emptyList()
        return arts to ops
    }

    /** Índice por Títulos para las pestañas Ley / Reglamento. */
    fun grupos(normaId: String): List<Grupo> {
        val its = items.filter { it.norma == normaId }
        val grupos = LinkedHashMap<String, MutableList<Item>>()
        val meta = HashMap<String, Pair<String, String>>()
        val tail = linkedMapOf<String, MutableList<Item>>()
        for (it in its) {
            if (it.t == "art") {
                val key = "T|" + it.tt
                grupos.getOrPut(key) { mutableListOf() }.add(it)
                meta.putIfAbsent(key, (it.tt.ifBlank { "Articulado" }) to it.tn)
            } else {
                val k = when (it.t) { "disp" -> "disp"; "anexo" -> "anexo"; else -> "otros" }
                tail.getOrPut(k) { mutableListOf() }.add(it)
            }
        }
        val out = grupos.map { (k, v) -> Grupo(k, meta[k]!!.first, meta[k]!!.second, v) }.toMutableList()
        for (k in listOf("disp", "anexo", "otros")) tail[k]?.let {
            out.add(Grupo(k, when (k) { "disp" -> "Disposiciones"; "anexo" -> "Anexos"; else -> "Otros textos" },
                if (k == "otros") "Encabezado y norma aprobatoria" else "", it))
        }
        return out
    }

    // ---------------- Modo literal ----------------
    fun frag(id: Int): Frag? = frags.getOrNull(id)?.takeIf { it.id == id } ?: frags.firstOrNull { it.id == id }
    fun itemOf(f: Frag): Item? = itemById[f.item]
    fun fragsOf(it: Item): List<Frag> = fragsByItem[it.id] ?: emptyList()

    /** "Reglamento, art. 194.2 d)" → fragmento (tolera espacios y mayúsculas). */
    fun fragByLabel(label: String): Frag? = fragByLabel[TextUtil.norm(label.trim()).replace(" ", "")]

    /** Referencia escrita por el usuario: "194.2 d", "art 120", "ley 64.3", "reglamento 212.6". */
    private val REF = Regex("^(ley|reglamento|rlgcp|lgcp)?\\s*(?:art[íi]culo|art\\.?)?\\s*(\\d{1,3})(?:\\.(\\d{1,2}))?\\s*(?:lit(?:eral)?\\.?\\s*)?([a-zñ])?\\)?\\s*(ley|reglamento)?$", RegexOption.IGNORE_CASE)

    fun buscarReferencia(q: String, normaId: String?): List<Frag> {
        val m = REF.find(q.trim()) ?: return emptyList()
        val norma = normaKey(m.groupValues[1].ifBlank { m.groupValues[5] }) ?: normaId
        val art = m.groupValues[2]
        val num = m.groupValues[3].let { if (it.isBlank()) "" else "$art.$it" }
        val lit = m.groupValues[4].lowercase()
        return frags.filter { f ->
            (norma == null || f.norma == norma) && f.art == art &&
                (num.isBlank() || f.num == num) && (lit.isBlank() || f.lit == lit)
        }.sortedBy { if (it.norma == "reglamento") 0 else 1 }
    }

    fun searchFrags(q: String, k: Int = 40, normaId: String? = null): List<Frag> {
        val ref = buscarReferencia(q, normaId)
        if (ref.isNotEmpty()) return ref.take(k)
        return idxF.search(q, k, if (normaId == null) null else { f: Frag -> f.norma == normaId })
    }

    /** Opiniones que citan el artículo del fragmento (por número de artículo y norma). */
    fun opinionesDe(normaId: String, art: String): List<Opinion> {
        if (art.isBlank()) return emptyList()
        val corto = if (normaId == "ley") "ley" else "reglamento"
        val re = Regex("^$corto\\s+art\\.\\s*$art(\\b|\\.)", RegexOption.IGNORE_CASE)
        return opiniones.filter { o -> o.articulos.any { re.containsMatchIn(TextUtil.norm(it)) } }
    }

    /** Cita formal para documentos: "el literal d) del numeral 194.2 del artículo 194 del Reglamento…". */
    fun citaFormal(f: Frag): String {
        val norma = if (f.norma == "ley") "de la Ley N.° 32069, Ley General de Contrataciones Públicas"
        else "del Reglamento de la Ley N.° 32069, Ley General de Contrataciones Públicas, aprobado por Decreto Supremo N.° 009-2025-EF"
        if (f.art.isBlank()) return "la ${f.ti} $norma"
        val partes = mutableListOf<String>()
        if (f.lit.isNotBlank()) partes.add("el literal ${f.lit})")
        if (f.num.isNotBlank()) partes.add((if (partes.isEmpty()) "el " else "del ") + "numeral ${f.num}")
        partes.add((if (partes.isEmpty()) "el " else "del ") + "artículo ${f.art}")
        return partes.joinToString(" ") + " $norma"
    }

    fun textoParaCopiar(f: Frag): String {
        val cuerpo = (if (f.lit.isNotBlank() && f.intro.isNotBlank()) f.intro + "\n" else "") +
            (if (f.lit.isNotBlank()) "${f.lit}) " else "") + f.texto
        return "“${cuerpo.trim()}”\n\n— Conforme a ${citaFormal(f)}." +
            (if (f.nota.isNotBlank()) "\n(Nota: ${f.nota})" else "")
    }
}
