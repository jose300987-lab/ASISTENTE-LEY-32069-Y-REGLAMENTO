package pe.contrataciones.asistente.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import pe.contrataciones.asistente.ai.Assistant
import pe.contrataciones.asistente.ai.ClaudeApi
import pe.contrataciones.asistente.ai.Updater
import pe.contrataciones.asistente.data.Ficha
import pe.contrataciones.asistente.data.Frag
import pe.contrataciones.asistente.data.Item
import pe.contrataciones.asistente.data.Opinion
import pe.contrataciones.asistente.data.Prefs
import pe.contrataciones.asistente.data.Repo
import pe.contrataciones.asistente.voice.Voz
import java.io.File

data class ChatMsg(
    val user: Boolean,
    val text: String,
    val used: List<Item> = emptyList(),
    val ops: List<Opinion> = emptyList(),
    val error: Boolean = false,
    val avisos: List<String> = emptyList()
)

enum class Tab(val titulo: String, val icono: String) {
    BUSCAR("Buscar", "🔎"), FICHAS("Trámites", "🗂️"), NORMAS("Normas", "📘"), OPINIONES("Opiniones", "⚖️"), AJUSTES("Ajustes", "⚙️")
}

class AppVM(app: Application) : AndroidViewModel(app) {
    val repo = Repo(app)
    val prefs = Prefs(app)
    val voz = Voz(app)
    private val assistant = Assistant(repo)

    var cargado by mutableStateOf(false); private set
    var tab by mutableStateOf(Tab.BUSCAR)
    var normaSel by mutableStateOf("reglamento")
    var chatAbierto by mutableStateOf(false)
    var resaltar by mutableStateOf<Frag?>(null)
    var verFicha by mutableStateOf<Ficha?>(null)
    var favoritos by mutableStateOf<Set<Int>>(emptySet()); private set
    val chat = mutableStateListOf<ChatMsg>()
    var ocupado by mutableStateOf(false); private set
    val pasos = mutableStateListOf<String>()
    var verItem by mutableStateOf<Item?>(null)
    var verOpinion by mutableStateOf<Opinion?>(null)
    var hablando by mutableStateOf(false); private set
    var buscandoNovedades by mutableStateOf(false); private set
    var estadoNovedades by mutableStateOf(""); private set
    var version by mutableStateOf(0); private set   // cambia cuando llegan opiniones o novedades nuevas

    private var job: Job? = null
    private val historyFile = File(app.filesDir, "chat.json")

    init {
        voz.hablando = { v -> viewModelScope.launch(Dispatchers.Main) { hablando = v } }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.load() }
            cargarChat()
            favoritos = prefs.favoritos
            cargado = true
        }
    }

    fun hayClave() = prefs.apiKey.isNotBlank()

    fun enviar(q: String) {
        val pregunta = q.trim()
        if (pregunta.isEmpty() || ocupado) return
        if (!hayClave()) {
            chat.add(ChatMsg(true, pregunta))
            chat.add(ChatMsg(false, "Para consultar, ingrese su clave de la API de Claude en **Ajustes**.", error = true))
            return
        }
        voz.detener()
        val history = chat.filter { !it.error }.zipWithNext().filter { it.first.user && !it.second.user }
            .map { it.first.text to it.second.text }
        chat.add(ChatMsg(true, pregunta))
        ocupado = true
        pasos.clear()
        job = viewModelScope.launch {
            try {
                val api = ClaudeApi(prefs.apiKey, prefs.model)
                val r = assistant.ask(api, history, pregunta, prefs.incluirOpiniones, prefs.graficos) { s ->
                    viewModelScope.launch(Dispatchers.Main) { pasos.add(s) }
                }
                chat.add(ChatMsg(false, r.text, r.used, r.ops, avisos = r.avisos))
                if (prefs.voz != "off") voz.hablar(r.text, prefs.voz)
            } catch (e: kotlinx.coroutines.CancellationException) {
                chat.add(ChatMsg(false, "Consulta detenida.", error = true))
            } catch (e: Exception) {
                chat.add(ChatMsg(false, ClaudeApi.friendly(e), error = true))
            } finally {
                ocupado = false
                pasos.clear()
                guardarChat()
            }
        }
    }

    fun detener() { job?.cancel() }

    fun esFavorito(f: Frag) = f.id in favoritos
    fun alternarFavorito(f: Frag) {
        favoritos = if (f.id in favoritos) favoritos - f.id else favoritos + f.id
        prefs.favoritos = favoritos
    }

    /** Abre el artículo completo con el numeral o literal resaltado. */
    fun abrirFrag(f: Frag) {
        resaltar = f
        verItem = repo.itemOf(f)
    }

    fun abrirFragId(id: Int) { repo.frag(id)?.let { abrirFrag(it) } }

    /** Pide a la IA que explique un fragmento usando solo ese artículo y los que este remita. */
    fun explicar(f: Frag) {
        preguntarSobre("Explique en lenguaje sencillo ${f.label}: qué exige, quién debe hacerlo y en qué plazo. " +
            "Use solo el texto de ese artículo y los artículos a los que remita; cite cada afirmación.")
    }

    fun nuevaConversacion() {
        if (ocupado) return
        voz.detener()
        chat.clear()
        guardarChat()
    }

    fun escuchar(texto: String) = voz.hablar(texto, if (prefs.voz == "breve") "breve" else "full")
    fun callar() = voz.detener()

    /** Cita pulsada en una respuesta: "Reglamento, art. 194.2 d)" o "Opinión D000092-2026-OECE-DTN". */
    fun abrirCita(raw: String) {
        val op = Regex("(D\\d{6}-\\d{4}-OECE-DTN)", RegexOption.IGNORE_CASE).find(raw)
        if (raw.trim().lowercase().startsWith("opini") && op != null) {
            verOpinion = repo.opinion(op.value)
            return
        }
        repo.fragByLabel(raw)?.let { abrirFrag(it); return }
        resaltar = null
        val partes = raw.split(",", limit = 2)
        val norma = repo.normaKey(partes[0]) ?: return
        val resto = partes.getOrElse(1) { "" }
        val art = Regex("art(?:[íi]culo|s?\\.)\\s*(\\d{1,3}(?:-?[A-Z])?)", RegexOption.IGNORE_CASE).find(resto)
        verItem = if (art != null) repo.getArticle(norma, art.groupValues[1].replace("-", ""))
        else repo.findDisposicion(norma, resto)
    }

    fun preguntarSobre(texto: String) {
        chatAbierto = true
        verFicha = null
        verItem = null
        verOpinion = null
        enviar(texto)
    }

    fun buscarNovedades() {
        if (buscandoNovedades) return
        if (!hayClave()) { estadoNovedades = "Primero ingrese su clave de la API."; return }
        buscandoNovedades = true
        estadoNovedades = "Buscando en gob.pe y El Peruano… (puede tardar 1 a 2 minutos)"
        viewModelScope.launch {
            try {
                val r = Updater.run(ClaudeApi(prefs.apiKey, prefs.model), repo, prefs)
                estadoNovedades = r.resumen
                version++
            } catch (e: Exception) {
                estadoNovedades = ClaudeApi.friendly(e)
            } finally {
                buscandoNovedades = false
            }
        }
    }

    fun cambiarAuto(modo: String) {
        prefs.autoUpdate = modo
        Updater.schedule(getApplication(), modo)
    }

    private fun guardarChat() {
        val arr = JSONArray()
        chat.takeLast(30).forEach { arr.put(JSONObject().put("u", it.user).put("t", it.text).put("e", it.error)) }
        runCatching { historyFile.writeText(arr.toString()) }
    }

    private fun cargarChat() {
        runCatching {
            val arr = JSONArray(historyFile.readText())
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                chat.add(ChatMsg(j.getBoolean("u"), j.getString("t"), error = j.optBoolean("e")))
            }
        }
    }

    override fun onCleared() {
        voz.cerrar()
        super.onCleared()
    }
}
