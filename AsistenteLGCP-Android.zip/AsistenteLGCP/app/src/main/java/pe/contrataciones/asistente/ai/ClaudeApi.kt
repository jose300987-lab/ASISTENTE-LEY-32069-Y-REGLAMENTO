package pe.contrataciones.asistente.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val code: Int, message: String) : Exception(message)

/**
 * Cliente mínimo de la API de mensajes de Claude (https://api.anthropic.com/v1/messages).
 * Sin librerías externas: HttpURLConnection + org.json.
 */
class ClaudeApi(private val apiKey: String, private val model: String) {

    suspend fun create(body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val payload = JSONObject(body.toString()).put("model", model)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 30_000
            c.readTimeout = 240_000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", apiKey)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                    .getOrDefault(txt.take(300))
                throw ApiException(code, msg)
            }
            JSONObject(txt)
        } finally {
            c.disconnect()
        }
    }

    companion object {
        /** Mensaje entendible para el usuario. */
        fun friendly(e: Throwable): String = when {
            e is ApiException && e.code == 401 -> "La clave de la API no es válida. Revísela en Ajustes."
            e is ApiException && e.code == 400 && e.message?.contains("credit", true) == true ->
                "Su cuenta de la API no tiene saldo. Recárguelo en console.anthropic.com."
            e is ApiException && e.code == 429 -> "Se alcanzó el límite de consultas por minuto. Espere un momento e intente de nuevo."
            e is ApiException && e.code >= 500 -> "El servicio de Claude no responde en este momento. Intente de nuevo."
            e is ApiException -> "Error de la API (${e.code}): ${e.message}"
            e is java.net.UnknownHostException -> "Sin conexión a internet."
            e is java.net.SocketTimeoutException -> "La respuesta tardó demasiado. Intente con una pregunta más concreta."
            else -> "Ocurrió un problema: ${e.message ?: e.javaClass.simpleName}"
        }
    }
}

/** Texto de los bloques "text" de una respuesta. */
fun JSONObject.textOf(): String {
    val arr = optJSONArray("content") ?: return ""
    val sb = StringBuilder()
    for (i in 0 until arr.length()) {
        val b = arr.getJSONObject(i)
        // Con búsqueda web, el texto llega partido en varios bloques (por las citas): se concatena tal cual.
        if (b.optString("type") == "text") sb.append(b.optString("text"))
    }
    return sb.toString().trim()
}
