# Sin reglas especiales: la app usa org.json y HttpURLConnection del sistema.
