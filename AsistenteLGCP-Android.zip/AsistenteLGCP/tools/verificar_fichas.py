"""Genera app/src/main/assets/fichas.json desde fichas_src.json y verifica que cada
plazo y cita aparezcan literalmente en el numeral referido. Uso: python tools/verificar_fichas.py"""
import json, re, sys, pathlib
A = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/assets"
fr = json.load(open(A / "fragmentos.json", encoding="utf-8"))
L = {x["label"]: x for x in fr}
n = lambda s: re.sub(r"\s+", " ", s.replace("“", '"').replace("”", '"')).strip().lower()
src = json.load(open(pathlib.Path(__file__).parent / "fichas_src.json", encoding="utf-8"))
err = 0
for f in src:
    for p in f["pasos"] + f.get("limites", []):
        x = L.get(p["ref"])
        if not x: print("No existe", p["ref"]); err += 1; continue
        t = n(x["intro"] + " " + x["texto"])
        for k in ("plazo", "cita"):
            if p.get(k) and n(p[k]) not in t: print("No aparece literalmente:", f["id"], p["ref"], k, p[k]); err += 1
        p["frag"] = x["id"]
if err: sys.exit(f"{err} errores: no se genera fichas.json")
json.dump(src, open(A / "fichas.json", "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print("OK:", len(src), "fichas verificadas")
