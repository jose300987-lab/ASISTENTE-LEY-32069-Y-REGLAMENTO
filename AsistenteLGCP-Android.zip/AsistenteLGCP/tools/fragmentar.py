"""Divide la Ley y el Reglamento en fragmentos citables (numeral / literal), quedándose con el texto vigente."""
import json, re, sys
A = "/home/claude/android/AsistenteLGCP/app/src/main/assets/"
Q = '"“”'
def clean(s): return s.strip().strip(Q).strip()

def split_article(norma, corto, it):
    art = it["n"]; lines = [l for l in it["x"].split("\n")]
    order, frags = [], {}
    cur_num = None; cur_id = None; pending_note = []; in_note = False; sin_lit = set()
    re_num = re.compile(r'^[' + Q + r']?\s*' + re.escape(art) + r'\.(\d{1,2})\.?\s+(.*)$')
    re_lit = re.compile(r'^[' + Q + r']?\s*([a-z])\)\s+(.*)$')
    re_newart = re.compile(r'^[' + Q + r']\s*Art[íi]culo\s+' + re.escape(art) + r'\b')
    def put(fid, num, lit, text, intro=""):
        nonlocal cur_id
        quoted = False
        if fid in frags:   # nueva versión del mismo numeral/literal (texto modificado): reemplaza
            frags[fid]["texto"] = text; quoted = True
        else:
            order.append(fid); frags[fid] = {"num": num, "lit": lit, "texto": text, "intro": intro, "nota": ""}
        if pending_note:
            frags[fid]["nota"] = " ".join(pending_note).strip()
            pending_note.clear()
        cur_id = fid
    for raw in lines:
        l = raw.strip()
        if not l: continue
        if l.startswith("(*)"):
            in_note = True; pending_note.append(l[3:].strip()); continue
        if re_newart.match(l):       # artículo completo sustituido: se descarta la versión anterior
            order.clear(); frags.clear(); in_note = False; cur_num = None; cur_id = None; continue
        m = re_num.match(l)
        if m:
            in_note = False
            cur_num = f"{art}.{m.group(1)}"
            put(cur_num, cur_num, "", clean(m.group(2)) if l[0] not in Q else clean(m.group(2)))
            continue
        m = re_lit.match(l)
        if m and cur_num and not in_note and cur_num not in sin_lit:
            fid = f"{cur_num} {m.group(1)})"
            if fid in frags and l[0] not in Q:
                # La secuencia de literales se reinicia (p. ej. "Para obras: a) b) c) / Para consultorías: a) b)"):
                # no se puede citar por literal sin ambigüedad, así que el numeral queda entero.
                sin_lit.add(cur_num)
                for k in [k for k in order if k.startswith(cur_num + " ")]:
                    frags[cur_num]["texto"] += "\n" + k.split(" ", 1)[1] + " " + frags[k]["texto"]
                    order.remove(k); del frags[k]
                frags[cur_num]["texto"] += "\n" + l
                cur_id = cur_num
                continue
            intro = frags[cur_num]["texto"] if cur_num in frags else ""
            put(fid, cur_num, m.group(1), clean(m.group(2)), intro[:220])
            continue
        if in_note:
            pending_note.append(l); continue
        if cur_id: frags[cur_id]["texto"] += "\n" + clean(l)
        else:
            order.append("_") if "_" not in frags else None
            frags.setdefault("_", {"num": "", "lit": "", "texto": "", "intro": "", "nota": ""})
            frags["_"]["texto"] += ("\n" if frags["_"]["texto"] else "") + clean(l)
            cur_id = "_"
    if pending_note and order:   # nota sin texto nuevo identificado: se adjunta al último fragmento
        frags[order[-1]]["nota"] = (frags[order[-1]]["nota"] + " " + " ".join(pending_note)).strip()
    out = []
    if not [k for k in order if k != "_"]:
        txt = "\n".join(frags[k]["texto"] for k in order)
        nota = " ".join(frags[k]["nota"] for k in order if frags[k]["nota"])
        return [{"norma": norma, "art": art, "num": "", "lit": "", "label": f"{corto}, art. {art}", "texto": txt.strip(), "intro": "", "nota": nota}]
    for k in order:
        f = frags[k]
        if k == "_":
            if not f["texto"].strip(): continue
            label = f"{corto}, art. {art}"
        else:
            label = f"{corto}, art. {k}"
        out.append({"norma": norma, "art": art, "num": f["num"], "lit": f["lit"], "label": label,
                    "texto": f["texto"].strip(), "intro": f["intro"], "nota": f["nota"]})
    return out

todos = []
for fn in ["ley", "reglamento"]:
    d = json.load(open(A + fn + ".json"))
    for idx, it in enumerate(d["items"]):
        base = {"item": f"{fn}:{idx}", "ti": it["ti"], "tt": it.get("tt", ""), "ct": it.get("ct", "")}
        if it["t"] == "art":
            for f in split_article(fn, d["corto"], it): todos.append({**f, **base})
        elif it["t"] == "disp":
            todos.append({"norma": fn, "art": "", "num": "", "lit": "", "label": f"{d['corto']}, {it['ti']}",
                          "texto": it["x"].strip(), "intro": "", "nota": "", **base})
for i, f in enumerate(todos): f["id"] = i
json.dump(todos, open(A + "fragmentos.json", "w"), ensure_ascii=False, separators=(",", ":"))
print("fragmentos:", len(todos))
by = {}
for f in todos: by[f["label"]] = f
for k in ["Reglamento, art. 120.1", "Reglamento, art. 119.1", "Ley, art. 64.3 a)", "Reglamento, art. 198.1", "Reglamento, art. 200.1"]:
    f = by.get(k); print("---", k, "\n", (f["texto"][:300] if f else "NO ENCONTRADO"), "\n NOTA:", (f["nota"][:150] if f else ""))
dups = {}
for f in todos: dups[f["label"]] = dups.get(f["label"], 0) + 1
print("labels duplicados:", [k for k, v in dups.items() if v > 1][:15])
print("con nota:", sum(1 for f in todos if f["nota"]))
