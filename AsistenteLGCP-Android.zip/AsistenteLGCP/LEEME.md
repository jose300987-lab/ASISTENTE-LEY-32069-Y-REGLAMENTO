# Asistente LGCP – App Android (modo literal)

Consulta de la **Ley N.° 32069** y su **Reglamento** que muestra **solo el texto oficial**: cada resultado es un numeral o literal con su cita exacta. Funciona **sin internet y sin clave de API**. La explicación con IA es opcional.

## Qué incluye
| Pestaña | Contenido |
|---|---|
| 🔎 Buscar | Búsqueda por palabras o por numeral (`194.2 d`, `ley 64.3`, `art 120`) sobre 2 329 numerales y literales. Resalta las palabras buscadas; ☆ favoritos; **Copiar con cita** (ej. "…conforme al literal d) del numeral 194.2 del artículo 194 del Reglamento…"); **Compartir** por WhatsApp u otra app; opiniones del OECE que citan ese artículo; dictado 🎤 |
| 🗂️ Trámites | 7 fichas paso a paso con línea de tiempo: adicional de obra, ampliación de plazo, penalidad por mora (con calculadora), resolución de contrato (con calculadora del plazo de apercibimiento), valorizaciones, recepción de obra (con calculadora del plazo de subsanación) y liquidación. Cada plazo se muestra con las **palabras exactas** del Reglamento o la Ley y enlaza al numeral |
| 📘 Normas | Ley y Reglamento por Títulos y Capítulos, con rango de artículos y lector. Al abrir un resultado, el numeral aparece resaltado |
| ⚖️ Opiniones | 21 opiniones de la DTN del OECE (2025–2026) con enlace a gob.pe |
| ⚙️ Ajustes | Clave de la API (opcional), modelo, voz, actualizaciones y novedades |

**Cómo se garantiza que no haya "alucinaciones":** la búsqueda y las fichas no generan texto. Las fichas se armaron con un programa que comprueba que cada plazo citado aparece literalmente en el numeral referido; si no aparece, la ficha no se compila.

**Explicar con IA (opcional):** si ingresa una clave de la API de Claude aparece el botón ✨. La IA redacta solo con los numerales recuperados y cada respuesta pasa por un **verificador automático**: comprueba que cada artículo citado exista y que cada plazo o porcentaje escrito ("10 días", "15 %") figure en el artículo citado (en cifras o en letras). Si algo no cuadra, se muestra un aviso ⚠.

- **Textos incluidos:** Ley actualizada al 19.07.2026 y Reglamento actualizado al 26.10.2026, en la versión que publica el OECE en gob.pe (fuente: SPIJ).

## 1. (Opcional) Clave de la API para "Explicar con IA" y actualizaciones automáticas
1. Entre a **https://console.anthropic.com** y cree una cuenta (es distinta de su suscripción de claude.ai).
2. En **Billing**, cargue saldo con tarjeta.
3. En **Settings → API Keys**, cree una clave (empieza con `sk-ant-`).
4. En la app, vaya a **Ajustes → Clave de la API**, péguela y toque **Guardar**. La clave queda solo en su teléfono.

**Costo referencial:** Sonnet 5.5 cuesta US$ 2 por millón de tokens de entrada y US$ 10 por millón de salida; Haiku 5.5 desde US$ 0.10 y US$ 0.50. Una consulta típica envía entre 15 000 y 30 000 tokens (los artículos recuperados) y recibe 1 000 a 2 000. Con Sonnet eso sale aproximadamente entre US$ 0.05 y 0.10 por pregunta, y con Haiku unas veinte veces menos. Las búsquedas de actualizaciones se cobran aparte. Revise sus consumos en la consola.

## 2. Instalar la app (elija una opción)

### Opción A – Android Studio (recomendada)
1. Instale **Android Studio** (versión 2024.2 o más reciente).
2. **File → Open** y elija la carpeta `AsistenteLGCP`. Espere a que termine el *Gradle Sync*; la primera vez descarga dependencias y tarda varios minutos.
3. Conecte su celular por USB con la **depuración USB** activada (Ajustes → Acerca del teléfono → toque 7 veces "Número de compilación" → Opciones de desarrollador → Depuración USB).
4. Pulse **Run ▶**. La app se instala y se abre.
5. Para obtener un APK que pueda compartir: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

Si Android Studio propone actualizar el *Android Gradle Plugin*, puede aceptar.

### Opción B – Sin Android Studio (GitHub)
1. Cree un repositorio en GitHub y suba esta carpeta.
2. En la pestaña **Actions**, elija **Compilar APK** y luego **Run workflow**.
3. Al terminar (unos 5 a 8 minutos), descargue **Asistente-LGCP-apk**, pase el `app-debug.apk` al celular y ábralo. Permita "instalar apps de origen desconocido" para ese caso.

## 3. Uso
- **Buscar por numeral:** escriba `194.2 d` o `reglamento 212.6`. **Por tema:** `ampliación de plazo supervisor`.
- **Copiar con cita:** en cada resultado, *Copiar* pone en el portapapeles el texto entre comillas y la cita formal, listo para un informe.
- **Trámites:** toque un paso para leer el numeral completo; las calculadoras usan la fórmula y los porcentajes del texto.
- **IA (opcional):** botón ✨ en la cabecera, en un resultado o en un artículo.

## Actualizar los textos de la Ley o el Reglamento
Las opiniones nuevas se agregan solas. Cuando una norma modifique la Ley o el Reglamento, la app lo avisa en **Ajustes → Novedades**, pero el texto completo se actualiza con una nueva versión de la app: se reemplazan `ley.json`, `reglamento.json` y `fragmentos.json` (se generan con `tools/`) y se vuelve a compilar.

## Estructura del proyecto
```
app/src/main/
  assets/            ley.json, reglamento.json, fragmentos.json (numerales y literales), fichas.json, opiniones.json
  java/pe/contrataciones/asistente/
    data/            Modelos, buscador (BM25), repositorio y ajustes
    ai/              Cliente de la API, asistente, verificador de citas y actualizador
    voice/           Lectura en voz alta
    ui/              Pantallas (Compose): Literal.kt (búsqueda, trámites, calculadoras), Screens.kt
```

> Herramienta de consulta: no reemplaza la revisión del texto oficial ni la opinión legal.
